#!/bin/zsh
set -e
TASK_APP_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
if [[ ! -x "$TASK_APP_DIR/.venv/bin/python3" ]]; then
  TASK_BUNDLED_PYTHON="$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3"
  if [[ -x "$TASK_BUNDLED_PYTHON" ]]; then TASK_PYTHON="$TASK_BUNDLED_PYTHON"; else TASK_PYTHON="$(command -v python3)"; fi
  "$TASK_PYTHON" -m venv "$TASK_APP_DIR/.venv"
  "$TASK_APP_DIR/.venv/bin/python3" -m pip install -r "$TASK_APP_DIR/requirements.txt"
fi
cd "$TASK_APP_DIR"
exec "$TASK_APP_DIR/.venv/bin/python3" "$TASK_APP_DIR/run_pipeline.py" --retrain
