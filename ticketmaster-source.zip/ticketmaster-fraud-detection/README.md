# Ticketmaster Fraud Detection Demo

**Independent reconstruction · synthetic data · not affiliated with Ticketmaster.**

A reproducible SQL → pandas → Python → Tableau project for practicing transaction risk, sales monitoring and review-policy economics. All 10,000 transactions and 1,000 accounts are independently generated; no company or customer records are included. The demo does not verify or reproduce an employer’s original business outcomes.

## Explore

[Interactive Tableau Public dashboard](https://public.tableau.com/app/profile/yuyuan.wang8232/viz/TicketmasterFraudDetectionDemo/01Salesandautomation)

- Four editable Tableau dashboards: Overview, Model performance, Risk policy, Scenario & ROI.
- SQL normalization, validation, deduplication and quarantine (36 seeded defects).
- pandas type handling, validated label joins and monthly reconciliation.
- A real gradient-boosting classifier with chronological splits and validation-only threshold selection.
- Local file monitoring, frozen-model refresh, Hyper exports and a rebuildable native workbook.

The held-out October sample has 818 transactions and 40 positive labels. TP=3, FP=33, FN=37, TN=745; recall=7.5%, precision=8.33%, average precision=0.0728. The low-recall baseline is retained for diagnosis. Scores are not calibrated probabilities. All monetary results are synthetic ticket GMV or hypothetical intervention economics, not realized protected revenue.

## Reproduce locally

```bash
python3 -m venv .venv
.venv/bin/python3 -m pip install -r requirements.txt
.venv/bin/python3 run_pipeline.py --stage all --retrain
.venv/bin/python3 -m unittest discover -s tests -v
.venv/bin/python3 server.py --open
```

Alternatively, double-click `rebuild.command` or `start.command` on macOS. The app serves only at 127.0.0.1:8766. Installation needs internet; computation remains local. No external account credentials are required.

Open `tableau/Ticketmaster Fraud Detection Demo.twbx` in Tableau Desktop/Public. The packaged workbook is a snapshot; reopen after a local refresh. The five scenario parameters change review costs, prevention and customer friction.

Technical exercises and resume-bullet mapping: `learning/START_HERE.md`. BigQuery SQL is a translation template; no cloud BigQuery job is deployed.

## Data boundaries

Labels need 60 days of observation and remain nullable until mature. Features use only information observable at each transaction. Training is Jan–Apr 2025, validation July, and held-out testing October, with observation gaps. The sales forecast is the mean of the prior three months. Reported efficiency, retention, annual leakage or hours saved from prior employment are not claims of this demo.
