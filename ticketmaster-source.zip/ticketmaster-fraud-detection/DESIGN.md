# Sky-blue theme

The visual direction is inspired by the Ticketmaster homepage (https://www.ticketmaster.com/), with a custom sky-blue palette for this independent learning demo. It is not an official Ticketmaster dashboard or exact brand specification.

Header: `#007fc7`; chart accent: `#009fe3`; secondary blue: `#026cdf`; text: `#182638`; borders: `#e1eaf1`. All interface text uses Arial/Helvetica.

The four native Tableau dashboards and five web pages share concise functional titles, a blue brand bar and white content areas. Resume-bullet mapping and longer teaching explanations remain in `learning/`.

Rebuild the workbook with `.venv/bin/python3 -m stages.build_tableau`; the new theme is stored in the generator. The synthetic data, saved classifier, calculated fields and evaluation policy are unchanged.

Screenshots: `tableau/previews/Overview.jpg` (native Tableau), `Preview.jpg` (web). Full native screenshots are retained alongside the cropped dashboard previews.
