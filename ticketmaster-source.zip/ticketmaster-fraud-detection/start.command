#!/bin/zsh
set -e
TASK_APP_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
if [[ ! -x "$TASK_APP_DIR/.venv/bin/python3" ]]; then
  TASK_BUNDLED_PYTHON="$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3"
  if [[ -x "$TASK_BUNDLED_PYTHON" ]]; then TASK_PYTHON="$TASK_BUNDLED_PYTHON"; else TASK_PYTHON="$(command -v python3)"; fi
  "$TASK_PYTHON" -m venv "$TASK_APP_DIR/.venv"
  echo "Installing the demo's Python dependencies into its local environment…"
  "$TASK_APP_DIR/.venv/bin/python3" -m pip install -r "$TASK_APP_DIR/requirements.txt"
fi
if ! "$TASK_APP_DIR/.venv/bin/python3" -c 'import sklearn, numpy, joblib, pandas, tableauhyperapi' >/dev/null 2>&1; then
  echo "Dependencies are missing. See README.md for environment setup."
  exit 1
fi
exec "$TASK_APP_DIR/.venv/bin/python3" "$TASK_APP_DIR/server.py" --open
