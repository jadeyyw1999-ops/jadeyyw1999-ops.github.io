import sys,json,sqlite3,tempfile,shutil,unittest,zipfile
from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from stages.prepare import prepare,monthly_reports
from stages.tableau_data import tables

class FullPipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.df=prepare(ROOT)
    def test_sql_quarantine_and_grain_reconcile(self):
        c=sqlite3.connect(ROOT/'data/transactions.sqlite')
        rows=c.execute('SELECT raw_rows,clean_rows,rejected_rows FROM cleaning_audit').fetchall()
        self.assertTrue(all(raw==clean+reject for raw,clean,reject in rows))
        self.assertEqual(c.execute('SELECT COUNT(*) FROM quarantine').fetchone()[0],36)
        self.assertEqual(c.execute('SELECT COUNT(*) FROM transactions').fetchone()[0],10000)
        self.assertFalse(c.execute('PRAGMA foreign_key_check').fetchall());c.close()
    def test_normalization_preserves_original_money_and_keys(self):
        source=sqlite3.connect(ROOT/'data/original.sqlite');clean=sqlite3.connect(ROOT/'data/transactions.sqlite')
        for table,cols in [('transactions','transaction_id,amount_cents,device_type,country_mismatch'),('accounts','account_id,created_at,country'),('outcomes','transaction_id,fraud_label,label_available_at')]:
            self.assertEqual(source.execute(f'SELECT {cols} FROM {table} ORDER BY 1').fetchall(),clean.execute(f'SELECT {cols} FROM {table} ORDER BY 1').fetchall())
        source.close();clean.close()
    def test_pandas_nullable_targets_and_split_boundaries(self):
        df=self.df
        self.assertEqual(str(df.fraud_label.dtype),'Int64');self.assertEqual(int(df.fraud_label.isna().sum()),1708)
        self.assertFalse(df.transaction_id.duplicated().any());self.assertEqual(df[df.cohort=='Train'].shape[0],3220)
        self.assertEqual(df[df.cohort=='Validation'].shape[0],846);self.assertEqual(df[df.cohort=='Test'].shape[0],818)
    def test_forecast_uses_only_earlier_months(self):
        a=monthly_reports(self.df);changed=self.df.copy();changed.loc[changed.month=='2025-12-01','amount']*=10;b=monthly_reports(changed)
        self.assertEqual([r['forecast_gmv'] for r in a],[r['forecast_gmv'] for r in b])
        self.assertAlmostEqual(a[3]['forecast_gmv'],sum(r['gmv'] for r in a[:3])/3)
    def test_sql_and_pandas_repeat_buyer_results_agree(self):
        c=sqlite3.connect(ROOT/'data/transactions.sqlite')
        q="WITH a AS(SELECT substr(transaction_at,1,7)||'-01' month,account_id,COUNT(*) n FROM transactions GROUP BY 1,2) SELECT month,COUNT(*) active_buyers,SUM(n>=2) repeat_buyers FROM a GROUP BY 1"
        sql=pd.read_sql_query(q,c);c.close();p=pd.DataFrame(monthly_reports(self.df))
        joined=p.merge(sql,on='month',validate='one_to_one',suffixes=('_p','_s'))
        self.assertTrue((joined.active_buyers_p==joined.active_buyers_s).all());self.assertTrue((joined.repeat_buyers_p==joined.repeat_buyers_s).all())
    def test_native_workbook_packaged_connections_and_formulas(self):
        import xml.etree.ElementTree as E
        with zipfile.ZipFile(ROOT/'tableau/Ticketmaster Fraud Detection Demo.twbx') as z:
            xml=z.read('Ticketmaster Fraud Detection Demo.twb');book=E.fromstring(xml)
            self.assertEqual(len(book.findall('./dashboards/dashboard')),4);self.assertEqual(len(book.findall('./worksheets/worksheet')),29)
            for c in book.findall('./datasources/datasource/extract/connection'):self.assertIn(c.get('dbname'),z.namelist())
            self.assertTrue(all(not c.get('dbname','').startswith('/') for c in book.findall('.//connection')))
            formulas=json.loads((ROOT/'tableau/calculated_fields.json').read_text())
            self.assertIn('[Parameters].[Prevention]',formulas['summary']['Avoidable loss'])
            self.assertEqual(formulas['summary']['Fraud recall'],'SUM([tp])/SUM([fraud])')
    def test_hyper_values_match_pandas(self):
        from tableauhyperapi import HyperProcess,Connection,Telemetry
        with HyperProcess(Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU) as h:
            with Connection(h.endpoint,str(ROOT/'tableau/Data/summary.hyper')) as c:
                tp,fp,fn,tn,gmv=c.execute_list_query('SELECT tp,fp,fn,tn,captured_fraud_gmv FROM "Extract"."Extract"')[0]
                self.assertEqual((tp,fp,fn,tn),(3,33,37,745));self.assertAlmostEqual(gmv,371.15)
if __name__=='__main__':unittest.main()
