import copy,importlib.util,json,shutil,sqlite3,sys,tempfile,threading,unittest
from pathlib import Path
from http.client import HTTPConnection
from http.server import ThreadingHTTPServer
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import pipeline
from server import Engine,Handler

class FeatureBoundaryTests(unittest.TestCase):
    def test_current_transaction_and_future_chargebacks_excluded(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'data').mkdir();(root/'sql').mkdir();shutil.copy(ROOT/'sql/features.sql',root/'sql/features.sql')
            c=sqlite3.connect(root/'data/transactions.sqlite');c.executescript((ROOT/'sql/schema.sql').read_text())
            c.execute("INSERT INTO metadata VALUES ('data_type','SYNTHETIC test')")
            c.execute("INSERT INTO accounts VALUES (1,'2024-01-01 00:00:00','US')")
            tx=[(1,'2025-01-02 23:59:59'),(2,'2025-01-03 00:00:00'),(3,'2025-01-09 00:00:00'),(4,'2025-01-10 00:00:00')]
            for tid,stamp in tx:c.execute('INSERT INTO transactions VALUES (?,?,?,10000,\'web\',0)',(tid,1,stamp))
            c.executemany('INSERT INTO chargeback_events VALUES (?,?)',[(1,'2025-01-09 23:59:59'),(2,'2025-01-10 00:00:00'),(3,'2025-01-11 00:00:00')]);c.commit();c.close()
            r=pipeline.features(root)[-1]
            self.assertEqual(r['purchase_count_7d'],2);self.assertEqual(r['prior_chargeback_count'],1)
            self.assertFalse(any(k in pipeline.FEATURES for k in ['fraud_label','label_available_at','chargeback_at']))
    def test_immature_labels_never_enter_time_split(self):
        rows=[dict(transaction_at='2025-07-15 00:00:00',fraud_label=0,label_available_at='2025-10-02 00:00:00'),dict(transaction_at='2025-07-16 00:00:00',fraud_label=None,label_available_at=None)]
        self.assertEqual(pipeline.split(rows,'validation'),[])
    def test_tied_scores_do_not_break_capacity_limit(self):
        rows=[dict(score=s,fraud_label=y,amount=100) for s,y in [(.9,1),(.9,0),(.1,0),(.1,1)]]
        threshold,m=pipeline.select_threshold(rows,.25)
        self.assertEqual(m['flagged'],0);self.assertGreater(threshold,.9)

class FinancialTests(unittest.TestCase):
    def test_confusion_matrix_and_exposure_reconcile(self):
        rows=[dict(score=s,fraud_label=y,amount=a) for s,y,a in [(.9,1,100),(.8,0,200),(.2,1,300),(.1,0,400)]]
        m=pipeline.metrics(rows,.5)
        self.assertEqual([m[k] for k in ['tp','fp','fn','tn']],[1,1,1,1]);self.assertEqual(m['captured_fraud_gmv'],100);self.assertEqual(m['flagged_gmv'],300);self.assertEqual(m['missed_fraud_gmv'],300)
    def test_scenario_zero_prevention_and_invalid_inputs(self):
        t=dict(captured_fraud_gmv=1000,flagged=10,fp=8)
        inputs=dict(review_cost=2,prevention_rate=0,loss_severity=1,friction_rate=.1,friction_cost=20)
        s=pipeline.scenario(t,inputs);self.assertEqual(s['net_value'],-36)
        with self.assertRaises(ValueError):pipeline.scenario(t,{**inputs,'prevention_rate':float('nan')})
        with self.assertRaises(ValueError):pipeline.scenario(t,{**inputs,'review_cost':-1})

class PipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.base=pipeline.build(ROOT)
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        for d in ['data','models','sql']:shutil.copytree(ROOT/d,self.root/d)
        shutil.copy(ROOT/'config.json',self.root/'config.json')
        self.e=Engine(self.root);self.e.good=copy.deepcopy(self.base);self.e.status='ready'
    def tearDown(self):self.tmp.cleanup()
    def test_replay_changes_queue_not_model_or_test(self):
        model_bytes=(self.root/'models/gradient_boosting.joblib').read_bytes();old=self.base['queue_summary']['n']
        self.e.replay();self.assertTrue(self.e.refresh())
        self.assertEqual(self.e.good['queue_summary']['n'],old+20);self.assertEqual(self.e.good['test'],self.base['test']);self.assertEqual((self.root/'models/gradient_boosting.joblib').read_bytes(),model_bytes)
        c=sqlite3.connect(self.root/'data/transactions.sqlite');self.assertEqual(c.execute('SELECT COUNT(*) FROM outcomes').fetchone()[0],8292);c.close()
        self.e.replay(True);self.assertTrue(self.e.refresh());self.assertEqual(self.e.good['queue_summary']['n'],old)
    def test_invalid_config_retains_data_and_marks_exports_stale(self):
        (self.root/'config.json').write_text('{broken')
        self.assertFalse(self.e.refresh());self.assertEqual(self.e.status,'stale');self.assertEqual(self.e.good['revision'],self.base['revision'])
        self.assertIn('stale',(self.root/'exports/monthly.csv').read_text());self.assertEqual(self.e.view()['runtime']['watch_seconds'],5)
    def test_changed_training_history_requires_explicit_retrain(self):
        c=sqlite3.connect(self.root/'data/transactions.sqlite');c.execute('UPDATE transactions SET amount_cents=amount_cents+100 WHERE transaction_id=1');c.commit();c.close()
        self.assertFalse(self.e.refresh());self.assertIn('Training history changed',self.e.error)
    def test_http_guards_and_source_files_not_exposed(self):
        http=ThreadingHTTPServer(('127.0.0.1',0),Handler);http.engine=self.e
        t=threading.Thread(target=http.serve_forever,daemon=True);t.start()
        try:
            for url,host,expected in [('/api/data','evil.example',403),('/config.json',f'127.0.0.1:{http.server_port}',404),('/data/transactions.sqlite',f'127.0.0.1:{http.server_port}',404),('/api/data',f'127.0.0.1:{http.server_port}',200)]:
                c=HTTPConnection('127.0.0.1',http.server_port);c.request('GET',url,headers={'Host':host});r=c.getresponse();r.read();self.assertEqual(r.status,expected);c.close()
        finally:http.shutdown();http.server_close();t.join()
if __name__=='__main__':unittest.main()
