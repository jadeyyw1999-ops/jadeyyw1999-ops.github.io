"""Create deterministic, fictional learning data. Python 3 standard library only.

Run from any directory: python3 build_data.py
Use --reset to regenerate this demo source and its restore point.
"""
from pathlib import Path
from datetime import datetime, timedelta
import calendar
import math
import random
import sqlite3

ROOT = Path(__file__).resolve().parent
SNAPSHOT = datetime(2026, 1, 1)


def iso(d):
    return d.strftime('%Y-%m-%d %H:%M:%S')


def month(i):
    return datetime(2024 + i // 12, i % 12 + 1, 1)


def db(folder, schema):
    path = ROOT / folder
    path.mkdir(exist_ok=True)
    dest = path / 'transactions.sqlite'
    dest.unlink(missing_ok=True)
    conn = sqlite3.connect(dest)
    conn.execute('PRAGMA foreign_keys=ON')
    conn.executescript(schema)
    conn.execute('CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL)')
    conn.executemany('INSERT INTO metadata VALUES (?,?)', [
        ('data_type', 'SYNTHETIC: no real company or customer data'),
        ('snapshot_exclusive', iso(SNAPSHOT)), ('currency', 'USD; money stored as integer cents'),
    ])
    return conn


def ticketmaster():
    r = random.Random(2026102601)
    c = db('data', '''
    CREATE TABLE accounts(account_id INTEGER PRIMARY KEY, created_at TEXT NOT NULL,
                          country TEXT NOT NULL);
    CREATE TABLE transactions(transaction_id INTEGER PRIMARY KEY,
      account_id INTEGER NOT NULL REFERENCES accounts, transaction_at TEXT NOT NULL,
      amount_cents INTEGER NOT NULL CHECK(amount_cents>0), device_type TEXT NOT NULL,
      country_mismatch INTEGER NOT NULL CHECK(country_mismatch IN(0,1)));
    CREATE TABLE outcomes(transaction_id INTEGER PRIMARY KEY REFERENCES transactions,
      fraud_label INTEGER NOT NULL CHECK(fraud_label IN(0,1)),
      label_available_at TEXT NOT NULL, chargeback_at TEXT);
    CREATE TABLE chargeback_events(transaction_id INTEGER PRIMARY KEY REFERENCES transactions,
      chargeback_at TEXT NOT NULL);
    CREATE INDEX tx_account_time ON transactions(account_id,transaction_at);
    ''')
    accounts = []
    for aid in range(1, 1001):
        created = datetime(2024, 7, 1) + timedelta(days=r.randrange(540))
        accounts.append((aid, created, r.choice(['US', 'US', 'US', 'CA', 'GB'])))
    c.executemany('INSERT INTO accounts VALUES (?,?,?)',
                  [(a, iso(t), country) for a, t, country in accounts])
    dates = sorted(datetime(2025, 1, 1) + timedelta(seconds=r.randrange(365*86400))
                   for _ in range(10000))
    history = {a: [] for a, _, _ in accounts}
    chargebacks = {a: [] for a, _, _ in accounts}
    for tid, t in enumerate(dates, 1):
        eligible = [x for x in accounts if x[1] <= t]
        aid, created, _ = r.choice(eligible)
        age = (t-created).total_seconds()/86400
        velocity = sum(t-timedelta(days=7) <= v < t for v in history[aid])
        prior_cb = sum(cb < t for cb in chargebacks[aid])
        mismatch = int(r.random() < .09)
        amount = int(max(2500, min(180000, r.lognormvariate(9.5, .65))))
        logit = -3.65 + 1.2*(age < 30) + .5*(velocity >= 2) + .9*mismatch
        logit += .35*(amount > 40000) + .65*(prior_cb > 0)
        positive = int(r.random() < 1/(1+math.exp(-logit)))
        available = t + timedelta(days=60)
        cb = t + timedelta(days=r.randrange(7, 46)) if positive else None
        if cb:
            chargebacks[aid].append(cb)
        # Complete labels appear only after a fixed 60-day observation window.
        c.execute('INSERT INTO transactions VALUES (?,?,?,?,?,?)',
                  (tid, aid, iso(t), amount, r.choice(['web', 'ios', 'android']), mismatch))
        if cb and cb < SNAPSHOT:
            c.execute('INSERT INTO chargeback_events VALUES (?,?)', (tid, iso(cb)))
        if available < SNAPSHOT:
            c.execute('INSERT INTO outcomes VALUES (?,?,?,?)',
                      (tid, positive, iso(available), iso(cb) if cb else None))
        history[aid].append(t)
    c.execute("INSERT INTO metadata VALUES ('target_definition', 'Simulated confirmed fraud/chargeback within 60 days; mature labels only')")
    c.commit()
    c.close()


if __name__ == '__main__':
    import argparse, shutil
    parser=argparse.ArgumentParser();parser.add_argument('--reset',action='store_true');args=parser.parse_args()
    target=ROOT/'data/transactions.sqlite'
    if target.exists() and not args.reset:parser.error('Source already exists. Use --reset to replace the synthetic data and restore point.')
    ticketmaster()
    shutil.copyfile(target,ROOT/'data/original.sqlite')
    print('Generated 10,000 independent synthetic transactions. Rebuild the model with pipeline.py --train.')
