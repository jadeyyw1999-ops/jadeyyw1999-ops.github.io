"""SQL cleansing followed by explicit, validated pandas preparation."""
from pathlib import Path
import hashlib,json,sqlite3
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]

def records(frame):
    """Retain missing outcomes as None instead of converting them to class zero."""
    return frame.astype(object).where(pd.notna(frame),None).to_dict('records')

def clean(root=ROOT):
    raw=root/'data/raw.sqlite'
    if not raw.exists():return None  # Small fixture support; production runs use raw.sqlite.
    sql=root/'sql/01_cleaning.sql';manifest=root/'data/clean_manifest.json'
    signature=hashlib.sha256(raw.read_bytes()+sql.read_bytes()).hexdigest()
    try:
        old=json.loads(manifest.read_text())
        if old['signature']==signature and (root/'data/transactions.sqlite').exists():return old
    except (OSError,ValueError,KeyError):pass
    target=root/'data/transactions.sqlite';temp=target.with_suffix('.cleaning.tmp');temp.unlink(missing_ok=True)
    c=sqlite3.connect(temp)
    try:
        c.execute('ATTACH DATABASE ? AS raw',(str(raw),))
        if c.execute('PRAGMA raw.integrity_check').fetchone()[0]!='ok':raise ValueError('Raw SQLite integrity check failed')
        label=c.execute("SELECT value FROM raw.metadata WHERE key='data_type'").fetchone()
        if not label or not label[0].startswith('SYNTHETIC'):raise ValueError('Raw input is not labeled synthetic')
        c.executescript(sql.read_text())
        audit=pd.read_sql_query('SELECT * FROM cleaning_audit',c)
        if not (audit.raw_rows==audit.clean_rows+audit.rejected_rows).all():raise ValueError('Raw/clean/quarantine reconciliation failed')
        if c.execute('PRAGMA foreign_key_check').fetchone():raise ValueError('Clean foreign keys do not reconcile')
        c.commit()
        q=pd.read_sql_query('SELECT * FROM quarantine ORDER BY source_table,ingest_id',c)
        profile=pd.read_sql_query('SELECT source_table,reason,COUNT(*) AS rows FROM quarantine GROUP BY 1,2',c)
    finally:c.close()
    temp.replace(target)
    out=root/'exports';out.mkdir(exist_ok=True)
    for name,frame in [('cleaning_audit',audit),('quarantine',q),('quality_issues',profile)]:
        frame.insert(0,'DataMode','SYNTHETIC');frame.to_csv(out/f'{name}.csv',index=False)
    result=dict(signature=signature,audit=records(audit),quarantined=len(q),policy='First valid ingestion wins each business key; rejected records retain raw lineage.')
    tmp=manifest.with_suffix('.tmp');tmp.write_text(json.dumps(result,indent=2));tmp.replace(manifest)
    return result

def prepare(root=ROOT,persist=True):
    cleaning=clean(root)
    c=sqlite3.connect(f'file:{root/"data/transactions.sqlite"}?mode=ro',uri=True)
    try:
        if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('Clean integrity check failed')
        if c.execute('PRAGMA foreign_key_check').fetchone():raise ValueError('Broken source relationships')
        df=pd.read_sql_query((root/'sql/features.sql').read_text(),c)
        labels=pd.read_sql_query('SELECT transaction_id,fraud_label,label_available_at FROM outcomes',c)
        before=len(df)
        df=df.merge(labels,on='transaction_id',how='left',validate='one_to_one',indicator='label_join')
        if len(df)!=before or df.transaction_id.duplicated().any():raise ValueError('pandas join changed transaction grain')
        for k in ['transaction_id','account_id','purchase_count_7d','prior_chargeback_count','country_mismatch','device_code']:df[k]=pd.to_numeric(df[k],errors='raise').astype('int64')
        for k in ['amount','account_age_days']:df[k]=pd.to_numeric(df[k],errors='raise').astype('float64')
        df['fraud_label']=pd.to_numeric(df.fraud_label,errors='raise').astype('Int64')
        tx_time=pd.to_datetime(df.transaction_at,utc=True,errors='raise');label_time=pd.to_datetime(df.label_available_at,utc=True,errors='raise')
        if (df.amount<=0).any() or (df.account_age_days<0).any():raise ValueError('Invalid numerical feature')
        if ((df.fraud_label.notna())&((label_time-tx_time)<pd.Timedelta(days=60))).any():raise ValueError('Label observation period shorter than 60 days')
        df['transaction_at']=tx_time.dt.strftime('%Y-%m-%d %H:%M:%S')
        df['label_available_at']=label_time.dt.strftime('%Y-%m-%d %H:%M:%S')
        df['month']=tx_time.dt.strftime('%Y-%m-01')
        df['label_mature']=(label_time<pd.Timestamp('2026-01-01',tz='UTC'))&df.fraud_label.notna()
        df['cohort']='History / waiting gap'
        for name,lo,hi,cut in [('Train','2025-01-01','2025-05-01','2025-07-01'),('Validation','2025-07-01','2025-08-01','2025-10-01'),('Test','2025-10-01','2025-11-01','2026-01-01')]:
            mask=(df.transaction_at>=lo)&(df.transaction_at<hi)&df.fraud_label.notna()&(df.label_available_at<cut)
            df.loc[mask,'cohort']=name
        df.loc[df.transaction_at>='2025-11-01','cohort']='Recent scoring'
        df['DataMode']='SYNTHETIC'
        # Independent SQL-vs-pandas controls catch join multiplication and currency mistakes.
        controls=pd.read_sql_query('SELECT substr(transaction_at,1,7)||\'-01\' month,COUNT(*) transactions,SUM(amount_cents) gmv_cents FROM transactions GROUP BY 1',c)
        grouped=df.groupby('month',as_index=False).agg(transactions=('transaction_id','size'),gmv=('amount','sum'))
        check=grouped.merge(controls,on='month',suffixes=('_pandas','_sql'),validate='one_to_one')
        if not (check.transactions_pandas==check.transactions_sql).all() or not ((check.gmv*100-check.gmv_cents).abs()<.001).all():raise ValueError('SQL/pandas row or amount reconciliation failed')
        if persist:
            folder=root/'data/prepared';folder.mkdir(exist_ok=True)
            temp=folder/'features.tmp';df.to_csv(temp,index=False);temp.replace(folder/'features.csv')
            (folder/'preparation_report.json').write_text(json.dumps(dict(rows=len(df),missing_labels=int(df.fraud_label.isna().sum()),positive_mature=int(df.loc[df.label_mature,'fraud_label'].sum()),cohorts=df.cohort.value_counts().to_dict(),joined_with='one_to_one',cleaning=cleaning),indent=2))
        return df
    finally:c.close()

def monthly_reports(df):
    # Distinct-account statistics are calculated at account-month grain first.
    counts=df.groupby(['month','account_id']).size().rename('purchases').reset_index()
    buyers=counts.assign(repeat=lambda x:(x.purchases>=2).astype(int)).groupby('month').agg(active_buyers=('account_id','size'),repeat_buyers=('repeat','sum'))
    monthly=df.groupby('month').agg(transactions=('transaction_id','size'),gmv=('amount','sum'))
    mature=df[df.label_mature].groupby('month').agg(mature=('transaction_id','size'),fraud=('fraud_label','sum'))
    monthly=monthly.join(buyers,validate='one_to_one').join(mature,validate='one_to_one').reset_index()
    monthly[['mature','fraud']]=monthly[['mature','fraud']].fillna(0).astype(int)
    monthly['fraud_rate']=monthly.fraud/monthly.mature.replace(0,float('nan'))
    monthly['coverage']=monthly.mature/monthly.transactions
    monthly['repeat_buyer_share']=monthly.repeat_buyers/monthly.active_buyers
    monthly['forecast_gmv']=monthly.gmv.shift(1).rolling(3,min_periods=3).mean()
    monthly['variance']=monthly.gmv-monthly.forecast_gmv
    monthly['variance_pct']=monthly.variance/monthly.forecast_gmv
    return records(monthly)

if __name__=='__main__':
    df=prepare();print(json.dumps(dict(rows=len(df),columns=list(df.columns)),indent=2))
