"""Build a deliberately imperfect, independent synthetic raw ingestion source."""
from pathlib import Path
import sqlite3,shutil
ROOT=Path(__file__).resolve().parents[1]
SCHEMA='''
CREATE TABLE raw_accounts(ingest_id INTEGER PRIMARY KEY,account_id TEXT,created_at TEXT,country TEXT);
CREATE TABLE raw_transactions(ingest_id INTEGER PRIMARY KEY,transaction_id TEXT,account_id TEXT,transaction_at TEXT,amount_cents TEXT,device_type TEXT,country_mismatch TEXT);
CREATE TABLE raw_outcomes(ingest_id INTEGER PRIMARY KEY,transaction_id TEXT,fraud_label TEXT,label_available_at TEXT,chargeback_at TEXT);
CREATE TABLE raw_chargeback_events(ingest_id INTEGER PRIMARY KEY,transaction_id TEXT,chargeback_at TEXT);
CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT);
'''
def seed(root=ROOT):
    target=root/'data/raw.sqlite';tmp=target.with_suffix('.tmp');tmp.unlink(missing_ok=True)
    source=sqlite3.connect(root/'data/original.sqlite');c=sqlite3.connect(tmp);c.executescript(SCHEMA)
    for table in ['accounts','transactions','outcomes','chargeback_events']:
        rows=source.execute(f'SELECT * FROM {table}').fetchall();raw=[]
        for i,row in enumerate(rows):
            values=[None if v is None else str(v) for v in row]
            if i%29==0:values=[None if v is None else ' '+v+' ' for v in values]
            if table=='transactions' and i%31==0:values[4]=values[4].upper()
            if table=='accounts' and i%17==0:values[2]=values[2].lower()
            raw.append(values)
        cols=len(raw[0]);c.executemany(f'INSERT INTO raw_{table} VALUES (NULL,{",".join("?" for _ in range(cols))})',raw)
        # Duplicate raw records are intentional. Clean-layer keys remain unique.
        for row in rows[:5]:c.execute(f'INSERT INTO raw_{table} VALUES (NULL,{",".join("?" for _ in range(cols))})',tuple(None if v is None else str(v) for v in row))
    c.executemany('INSERT INTO raw_accounts VALUES(NULL,?,?,?)',[
        ('bad-id','2025-01-01 00:00:00','US'),('2001','not-a-date','US'),('2002','2025-01-01 00:00:00',None)])
    c.executemany('INSERT INTO raw_transactions VALUES(NULL,?,?,?,?,?,?)',[
        ('bad-id','1','2025-08-01 00:00:00','10000','web','0'),
        ('20001','1','2025-08-01 00:00:00','-100','web','0'),
        ('20002','1','2025-08-01 00:00:00','free','web','0'),
        ('20003','99999','2025-08-01 00:00:00','10000','web','0'),
        ('20004','1','not-a-date','10000','web','0'),
        ('20005','1','2025-08-01 00:00:00','10000',None,'0'),
        ('20006','1','2025-08-01 00:00:00','10000','web','maybe'),
        ('20007','1','2026-01-02 00:00:00','10000','web','0')])
    c.executemany('INSERT INTO raw_outcomes VALUES(NULL,?,?,?,?)',[
        ('99999','1','2025-12-01 00:00:00',None),('10','2','2025-12-01 00:00:00',None),('11',None,'2025-12-01 00:00:00',None)])
    c.executemany('INSERT INTO raw_chargeback_events VALUES(NULL,?,?)',[('99999','2025-08-01 00:00:00'),('10','2026-02-01 00:00:00')])
    c.execute("INSERT INTO metadata VALUES('data_type','SYNTHETIC: independent raw learning data with deliberate quality defects')")
    c.commit();c.close();source.close();tmp.replace(target)
    shutil.copyfile(target,root/'data/raw_original.sqlite')
    return target
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--reset',action='store_true');a=p.parse_args()
    if (ROOT/'data/raw.sqlite').exists() and not a.reset:p.error('Raw source exists; use --reset to replace this synthetic ingestion source.')
    print(seed())
