"""Author editable native Tableau worksheets/dashboards and a local TWBX."""
from pathlib import Path
import copy,json,uuid,xml.etree.ElementTree as E
ROOT=Path(__file__).resolve().parents[1]
INK='#182638';BLUE='#009fe3';TEAL='#026cdf';GRAY='#62748a';LINE='#e1eaf1';SKY='#007fc7';PAPER='#f5f9fc'
def el(parent,tag,text=None,**attrs):
    n=E.SubElement(parent,tag,{k.replace('_','-'):str(v) for k,v in attrs.items()})
    if text is not None:n.text=str(text)
    return n

def build(root=ROOT):
    manifest=json.loads((root/'tableau/data_dictionary.json').read_text())
    book=E.Element('workbook',{'source-build':'2026.2.0','source-platform':'mac','version':'18.1'})
    changes=el(book,'document-format-change-manifest')
    for n in ['SheetIdentifierTracking','SortTagCleanup','WindowsPersistSimpleIdentifiers','WorksheetBackgroundTransparency','ZoneFriendlyName']:el(changes,n)
    prefs=el(book,'preferences');el(prefs,'preference',name='ui.encoding.shelf.height',value='24')
    s=el(book,'style');rule=el(s,'style-rule',element='worksheet');el(rule,'format',attr='font-family',value='Arial');el(rule,'format',attr='font-size',value='10')
    sources=el(book,'datasources');columns={};calculated={};params=[]
    par=el(sources,'datasource',hasconnection='false',inline='true',name='Parameters',version='18.1')
    for name,caption,value,low,high,step,fmt in [
        ('Prevention','Prevention success',.7,0,1,.05,'p0%'),('Severity','Loss severity',1,0,1,.05,'p0%'),
        ('ReviewCost','Cost per review',2,0,20,.5,'n"$"0.0'),('Friction','Legitimate friction',.03,0,.5,.01,'p0%'),('FrictionCost','Cost per friction event',20,0,100,5,'n"$"0'),
    ]:
        c=el(par,'column',caption=caption,datatype='real',name=f'[{name}]',param_domain_type='range',role='measure',type='quantitative',value=value,default_format=fmt)
        el(c,'calculation',**{'class':'tableau','formula':str(value)});el(c,'range',min=low,max=high,granularity=step);params.append(c)
    def metadata(parent,fields,extract=False):
        recs=el(parent,'metadata-records')
        for i,f in enumerate(fields):
            t=f['type'];r=el(recs,'metadata-record',**{'class':'column'})
            for k,v in [('remote-name',f['name']),('remote-type',129 if extract and t=='string' else 130 if t=='string' else 20 if t=='integer' else 5),('local-name','['+f['name']+']'),('parent-name','[Extract]' if extract else '['+parent.get('filename','')+']'),('remote-alias',f['name']),('ordinal',i),('local-type',t),('aggregation','Count' if t=='string' else 'Sum'),('contains-null','true')]:el(r,k,v)
    ds_elements={}
    for name,fields in manifest.items():
        ds=el(sources,'datasource',caption=name.replace('_',' ').title(),inline='true',name=name,version='18.1');ds_elements[name]=ds;columns[name]={};calculated[name]=set()
        conn=el(ds,'connection',**{'class':'textscan','directory':'Data','filename':name+'.csv','password':'','server':''})
        rel=el(conn,'relation',name=name+'.csv',table='['+name+'.csv]',type='table');cs=el(rel,'columns',character_set='UTF-8',header='yes',locale='en_US',separator=',')
        for i,f in enumerate(fields):el(cs,'column',datatype=f['type'],name=f['name'],ordinal=i)
        metadata(conn,fields)
        ext=el(ds,'extract',count='-1',enabled='true',units='records');hc=el(ext,'connection',**{'class':'hyper','dbname':'Data/'+name+'.hyper','schema':'Extract','tablename':'Extract','access-mode':'readonly','default-settings':'hyper','username':'tableau_internal_user'})
        el(hc,'relation',name='Extract',table='[Extract].[Extract]',type='table');metadata(hc,fields,True)
        for f in fields:
            dimension=f['type']=='string';c=el(ds,'column',datatype=f['type'],name='['+f['name']+']',role='dimension' if dimension else 'measure',type='nominal' if dimension else 'quantitative')
            if not dimension:c.set('default-format','n#,##0.0' if f['type']=='real' else 'n#,##0')
            columns[name][f['name']]=c
    def calc(ds,name,formula,fmt='n#,##0',dtype='real'):
        c=el(ds_elements[ds],'column',datatype=dtype,name=f'[{name}]',role='measure',type='quantitative',default_format=fmt)
        el(c,'calculation',**{'class':'tableau','formula':formula});columns[ds][name]=c;calculated[ds].add(name)
    for name,formula,fmt in [
        ('Fraud recall','SUM([tp])/SUM([fraud])','p0.0%'),('Review precision','SUM([tp])/SUM([flagged])','p0.0%'),('Review share','SUM([flagged])/SUM([n])','p0.0%'),('Average precision','AVG([ap])','n0.000'),
        ('Total GMV','SUM([total_gmv])','n"$"#,##0'),('Clean transactions','SUM([total_transactions])','n#,##0'),('Mature labels','SUM([mature_labels])','n#,##0'),('Quarantined rows','SUM([quarantined])','n#,##0'),
        ('Training rows','SUM([train_count])','n#,##0'),('Flagged transactions','SUM([flagged])','n#,##0'),('Identified fraud GMV','SUM([captured_fraud_gmv])','n"$"#,##0'),('Missed fraud GMV','SUM([missed_fraud_gmv])','n"$"#,##0'),
        ('Avoidable loss','SUM([captured_fraud_gmv])*[Parameters].[Prevention]*[Parameters].[Severity]','n"$"#,##0'),
        ('Review cost','SUM([flagged])*[Parameters].[ReviewCost]','n"$"#,##0'),
        ('Friction cost','SUM([fp])*[Parameters].[Friction]*[Parameters].[FrictionCost]','n"$"#,##0'),
        ('Net value','[Avoidable loss]-[Review cost]-[Friction cost]','n"$"#,##0'),
        ('Scenario ROI','IF ([Review cost]+[Friction cost])>0 THEN [Net value]/([Review cost]+[Friction cost]) END','p0.0%'),
    ]:calc('summary',name,formula,fmt)
    calc('roi_curve','Grid net value','SUM([captured_fraud_gmv]*[prevention_grid])*[Parameters].[Severity]-SUM([flagged])*[Parameters].[ReviewCost]-SUM([false_positives])*[Parameters].[Friction]*[Parameters].[FrictionCost]','n"$"#,##0')
    # Set native formats and stable category colors.
    for ds,fields in columns.items():
        for n,c in fields.items():
            if n in ['fraud_rate','mature_fraud_rate','repeat_buyer_share','coverage','recall','precision','review_rate','accuracy','budget','prevention_grid','variance_pct']:c.set('default-format','p0.0%')
            if n in ['gmv','forecast_gmv','value','captured_fraud_gmv','variance']:c.set('default-format','n"$"#,##0')
            if n in ['ap_decrease']:c.set('default-format','n0.0000')
    for ds,field,maps in [('sales','series',{'Actual GMV':BLUE,'Rolling forecast':TEAL}),('confusion','actual',{'Fraud':'#b44b42','Legitimate':TEAL})]:
        ss=el(ds_elements[ds],'style');rr=el(ss,'style-rule',element='mark');enc=el(rr,'encoding',attr='color',field=f'[none:{field}:nk]',type='palette')
        for label,color in maps.items():mp=el(enc,'map',to=color);el(mp,'bucket','"'+label+'"')
    worksheets=el(book,'worksheets');sheets=[]
    def sheet(name,ds,x=None,y=None,text=None,color=None,path=None,mark='Bar',x_dim=False,y_dim=False,kpi=False,sort=False):
        w=el(worksheets,'worksheet',name=name);sheets.append(name)
        title=el(el(el(w,'layout-options'),'title'),'formatted-text');el(title,'run',name,fontsize=12,fontname='Arial',fontcolor=INK)
        table=el(w,'table');view=el(table,'view');dss=el(view,'datasources');el(dss,'datasource',name=ds);el(dss,'datasource',name='Parameters')
        pdeps=el(view,'datasource-dependencies',datasource='Parameters')
        for c in params:pdeps.append(copy.deepcopy(c))
        deps=el(view,'datasource-dependencies',datasource=ds)
        for c in columns[ds].values():deps.append(copy.deepcopy(c))
        instances={}
        def ref(field,dimension=False,ordinal=False):
            if not field:return ''
            deriv='None' if dimension else 'User' if field in calculated[ds] else 'Sum';prefix='none' if dimension else 'usr' if deriv=='User' else 'sum';kind='ok' if ordinal else 'nk' if dimension else 'qk'
            n=f'[{prefix}:{field}:{kind}]'
            if n not in instances:el(deps,'column-instance',column='['+field+']',derivation=deriv,name=n,pivot='key',type='ordinal' if ordinal else 'nominal' if dimension else 'quantitative');instances[n]=1
            return f'[{ds}].{n}'
        xr=ref(x,x_dim);yr=ref(y,y_dim);tr=ref(text);cr=ref(color,True);pr=ref(path,True,True)
        if sort and y and x:el(view,'computed-sort',column=yr,direction='DESC',using=xr)
        el(view,'aggregation',value='true')
        style=el(table,'style')
        rr=el(style,'style-rule',element='worksheet');el(rr,'format',attr='display-field-labels',scope='rows',value='false');el(rr,'format',attr='display-field-labels',scope='cols',value='false');el(rr,'format',attr='background-color',value='#ffffff')
        for kind in ['gridline','zeroline','table-div','header-div']:
            rr=el(style,'style-rule',element=kind)
            for scope in ['rows','cols']:el(rr,'format',attr='line-visibility',scope=scope,value='off' if kind!='gridline' else 'on')
        rr=el(style,'style-rule',element='header');el(rr,'format',attr='font-size',value='9');el(rr,'format',attr='color',value=GRAY)
        rr=el(style,'style-rule',element='axis')
        for field,scope,dimension in [(xr,'cols',x_dim),(yr,'rows',y_dim)]:
            if field and not dimension:el(rr,'format',attr='title',**{'class':'0','field':field,'scope':scope,'value':''})
        panes=el(table,'panes');pane=el(panes,'pane',selection_relaxation_option='selection-relaxation-allow');el(el(pane,'view'),'breakdown',value='auto');el(pane,'mark',**{'class':mark});enc=el(pane,'encodings')
        for key,value in [('text',tr),('color',cr),('path',pr)]:
            if value:el(enc,key,column=value)
        ps=el(pane,'style');rr=el(ps,'style-rule',element='mark')
        for a,v in [('mark-color',BLUE),('mark-labels-show','true' if kpi or mark in ['Bar','Text'] else 'false'),('font-size','29' if kpi else '17' if mark=='Text' else '9'),('color',INK),('font-family','Arial')]:el(rr,'format',attr=a,value=v)
        el(table,'rows',yr);el(table,'cols',xr);el(w,'simple-id',uuid='{'+str(uuid.uuid5(uuid.NAMESPACE_DNS,'tm-'+name)).upper()+'}')
        return name
    # Native sheets, each backed by one well-defined data grain; no fact-table joins.
    for title in ['Total GMV','Clean transactions','Mature labels','Quarantined rows','Training rows','Average precision','Fraud recall','Review precision','Review share','Flagged transactions','Identified fraud GMV','Missed fraud GMV','Avoidable loss','Review cost','Friction cost','Net value','Scenario ROI']:sheet(title,'summary',text=title,mark='Text',kpi=True)
    sheet('Monthly sales and rolling forecast','sales',x='period',y='value',color='series',mark='Line',x_dim=True)
    sheet('Repeat buyers by month','monthly',x='period',y='repeat_buyer_share',mark='Line',x_dim=True)
    sheet('Fully matured fraud rates','monthly',x='period',y='mature_fraud_rate',mark='Line',x_dim=True)
    sheet('SQL quarantine by reason','quality',x='rows',y='issue',y_dim=True,sort=True)
    sheet('Precision recall curve','pr_curve',x='recall',y='precision',path='point_order',mark='Line')
    sheet('Test confusion matrix','confusion',x='decision',y='actual',text='count',mark='Text',x_dim=True,y_dim=True)
    sheet('Validation feature importance','importance',x='ap_decrease',y='name',y_dim=True,sort=True)
    sheet('Validation recall by capacity','validation',x='budget_label',y='recall',x_dim=True,mark='Line')
    sheet('Validation precision by capacity','validation',x='budget_label',y='precision',x_dim=True,mark='Line')
    sheet('Test transactions by risk tier','risk_tiers',x='n',y='risk_order',y_dim=True)
    sheet('Test fraud GMV by risk tier','risk_tiers',x='captured_fraud_gmv',y='risk_order',y_dim=True)
    sheet('Net value across prevention assumptions','roi_curve',x='prevention_grid',y='Grid net value',mark='Line',x_dim=True)
    dashboards=el(book,'dashboards');dashboard_sheets={}
    def dashboard(name,title,subtitle,note):
        dash=el(dashboards,'dashboard',name=name);lo=el(el(el(dash,'layout-options'),'title'),'formatted-text');el(lo,'run',title,fontsize=26,fontname='Arial',bold='true',fontcolor=INK)
        rr=el(el(dash,'style'),'style-rule',element='dashboard');el(rr,'format',attr='background-color',value=PAPER)
        el(dash,'size',maxheight=1000,maxwidth=1300,minheight=1000,minwidth=1300)
        el(el(dash,'datasources'),'datasource',name='Parameters');deps=el(dash,'datasource-dependencies',datasource='Parameters')
        for c in params:deps.append(copy.deepcopy(c))
        zones=el(dash,'zones');base=el(zones,'zone',h=100000,w=100000,x=0,y=0,id=0,type_v2='layout-basic');state={'id':0};dashboard_sheets[name]=[]
        def zone(x,y,w,h,kind='text',text=None,size=10,color=INK,bg=None,sheetname=None,param=None):
            state['id']+=1;at=dict(x=round(x/1300*100000),y=round(y/1000*100000),w=round(w/1300*100000),h=round(h/1000*100000),id=state['id'])
            if sheetname:at.update(name=sheetname,show_title='false');dashboard_sheets[name].append(sheetname)
            else:at.update(type_v2=kind)
            if param:at.update(param=f'[Parameters].[{param}]',mode='slider')
            z=el(base,'zone',**at)
            if text:el(el(z,'formatted-text'),'run',text,fontsize=size,fontcolor=color,fontname='Arial')
            rr=el(el(z,'zone-style'),'format',attr='margin',value=0)
            if bg:el(z.find('zone-style'),'format',attr='background-color',value=bg)
            return z
        zone(0,0,1300,68,bg=SKY)
        brand=zone(30,8,250,52,text='ticketmaster',size=24,color='#ffffff',bg=SKY)
        brand.find('./formatted-text/run').set('bold','true');brand.find('./formatted-text/run').set('italic','true')
        zone(300,24,650,25,text='Fraud detection demo',size=12,color='#ffffff',bg=SKY)
        zone(1080,26,190,20,text='SYNTHETIC  /  LOCAL',size=9,color='#ffffff',bg=SKY)
        zone(30,96,1010,42,kind='title')
        zone(30,143,1240,24,text=subtitle,size=11,color=GRAY)
        zone(30,959,1240,1,bg=LINE)
        zone(30,974,1240,18,text='Synthetic data · '+note+'  |  USD  |  Jade Wang',size=8,color=GRAY)
        return zone
    def kpis(z,items,y=190):
        width=1240/len(items)
        z(30,y,1240,104,bg='#ffffff')
        for i,(name,label,desc) in enumerate(items):
            x=30+i*width
            if i:z(x,y+15,1,74,bg=LINE)
            z(x+17,y+10,width-35,19,text=label,size=10,color=GRAY)
            z(x+13,y+30,width-30,44,sheetname=name)
            z(x+17,y+82,width-35,16,text=desc,size=8,color=GRAY)
    def chart(z,name,x,y,w,h,title=None,subtitle=None):
        z(x,y,w,h,bg='#ffffff')
        z(x+18,y+16,w-36,24,text=title or name,size=13)
        top=49
        if subtitle:z(x+18,y+44,w-36,23,text=subtitle,size=9,color=GRAY);top=80
        z(x+14,y+top,w-28,h-top-13,sheetname=name)
    z=dashboard('01 Sales and automation','Overview','Sales, buyer activity and data quality · January–December 2025','GMV is ticket value')
    kpis(z,[('Total GMV','Ticket GMV','All 2025 transactions'),('Clean transactions','Transactions','Clean transaction rows'),('Mature labels','Mature outcomes','60-day observation window'),('Quarantined rows','Quarantined records','Duplicates and invalid records')])
    chart(z,'Monthly sales and rolling forecast',30,320,780,285,title='Sales & forecast',subtitle='Actual GMV (blue) · prior-three-month forecast (orange)')
    chart(z,'Repeat buyers by month',830,320,440,285,title='Repeat buyers',subtitle='Accounts with 2+ purchases / active buyers')
    chart(z,'SQL quarantine by reason',30,625,650,320,title='Data quality',subtitle='Rejected source records by reason')
    chart(z,'Fully matured fraud rates',700,625,570,320,title='Fraud rate by month',subtitle='Complete 60-day labels only; recent months remain null')
    z=dashboard('02 Model diagnostics','Model performance','Gradient boosting · trained Jan–Apr · validated Jul · tested Oct 2025','Held-out test; scores are uncalibrated')
    kpis(z,[('Training rows','Training transactions','Labels known before July 1'),('Average precision','Average precision','Test prevalence: 0.049'),('Fraud recall','Recall','3 detected / 40 positive'),('Review precision','Precision','3 positive / 36 flagged')])
    chart(z,'Precision recall curve',30,320,780,300,title='Precision–recall curve',subtitle='October test set · average precision = 0.073')
    chart(z,'Test confusion matrix',830,320,440,300,title='Confusion matrix',subtitle='Actual outcome × review decision')
    chart(z,'Validation feature importance',30,640,1240,305,title='Feature importance',subtitle='Validation AP decrease after permutation; negative values retained')
    z=dashboard('03 Risk policy and exposure','Risk policy','Locked review threshold · October 2025 test set','Identified fraud GMV is not protected revenue')
    kpis(z,[('Review share','Review share','5% validation review budget'),('Flagged transactions','Flagged transactions','Held-out test only'),('Identified fraud GMV','Fraud GMV identified','Flagged positive transactions'),('Missed fraud GMV','Fraud GMV missed','Unflagged positive transactions')])
    chart(z,'Test transactions by risk tier',30,320,610,285,title='Transactions by risk tier',subtitle='High risk triggers review')
    chart(z,'Test fraud GMV by risk tier',660,320,610,285,title='Fraud GMV by risk tier',subtitle='Observed positive labels in the test sample')
    chart(z,'Validation recall by capacity',30,625,610,320,title='Recall by review capacity',subtitle='Validation set only; test policy stays fixed')
    chart(z,'Validation precision by capacity',660,625,610,320,title='Precision by review capacity',subtitle='Validation set only')
    z=dashboard('04 Scenario and ROI','Scenario & ROI','Review economics · October 2025 test set','Hypothetical costs and prevention; no annualization')
    for i,p in enumerate(['Prevention','Severity','ReviewCost','Friction','FrictionCost']):z(30+i*248,185,230,65,kind='paramctrl',param=p,bg='#ffffff')
    kpis(z,[('Avoidable loss','Avoidable loss','Fraud GMV × prevention × severity'),('Review cost','Review cost','All flagged transactions'),('Friction cost','Friction cost','Flagged legitimate customers'),('Net value','Net value','Avoidable loss minus both costs'),('Scenario ROI','ROI','Net value / total costs')],y=275)
    chart(z,'Net value across prevention assumptions',30,400,1240,365,title='Prevention rate & net value',subtitle='0–100% prevention · uses the review, loss severity and friction assumptions above')
    z(30,785,1240,145,bg='#ffffff')
    z(50,804,1200,24,text='Scenario notes',size=13)
    z(50,844,1190,70,text='At zero prevention, avoidable loss is $0 while review and friction costs remain.\nThese estimates use one test sample and assumed intervention effects. They do not represent realized revenue.\nAfter a pipeline refresh, reopen the local TWBX to load the updated data.',size=10,color=GRAY)
    for dash in dashboards:
        device=el(el(dash,'devicelayouts'),'devicelayout',name='Tablet')
        el(device,'size',sizing_mode='automatic')
        el(dash,'simple-id',uuid='{'+str(uuid.uuid5(uuid.NAMESPACE_DNS,'dashboard-'+dash.get('name'))).upper()+'}')
    windows=el(book,'windows',source_height=30)
    for name,names in dashboard_sheets.items():
        w=el(windows,'window',**{'class':'dashboard','maximized':'true','name':name});v=el(w,'viewpoints')
        for n in names:el(el(v,'viewpoint',name=n),'zoom',type='entire-view')
        el(w,'active',id=-1)
    for name in sheets:
        w=el(windows,'window',**{'class':'worksheet','name':name});el(w,'cards');el(w,'simple-id',uuid='{'+str(uuid.uuid5(uuid.NAMESPACE_DNS,'window-'+name)).upper()+'}')
    # Tableau's XML grammar requires field definitions before extract/style.
    for ds in ds_elements.values():
        ordered=sorted(list(ds),key=lambda c:{'connection':0,'column':1,'column-instance':1,'extract':2,'style':3}.get(c.tag,4))
        ds[:]=ordered
    E.indent(book,space='  ')
    dest=root/'tableau/Ticketmaster Fraud Detection Demo.twb';E.ElementTree(book).write(dest,encoding='utf-8',xml_declaration=True)
    from stages.tableau_data import package
    package(root)
    (root/'tableau/calculated_fields.json').write_text(json.dumps({ds:{n:c.find('calculation').get('formula') for n,c in cols.items() if c.find('calculation') is not None} for ds,cols in columns.items()},indent=2))
    print(f'{len(sheets)} editable worksheets; {len(dashboard_sheets)} dashboards; {dest}')
    return dest
if __name__=='__main__':
    import sys
    sys.path.insert(0,str(ROOT));build()
