"""pandas BI marts and local Hyper extracts; no publishing or telemetry."""
from pathlib import Path
import json,zipfile,shutil
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]

def tables(result,status='ready'):
    d=result;m=pd.DataFrame(d['monthly']);m['period']=pd.to_datetime(m.month).dt.strftime('%m %b')
    m['mature_fraud_rate']=m.fraud_rate.where(m.coverage>=.999)
    summary=dict(d['test'],total_transactions=d['totals']['transactions'],total_gmv=float(m.gmv.sum()),mature_labels=d['totals']['mature'],
        total_positive=d['totals']['fraud'],quarantined=d.get('cleaning',{}).get('quarantined',0),queue_count=d['queue_summary']['n'],
        train_count=d['model']['train_count'],validation_count=d['validation']['n'],threshold=d['model']['high_threshold'])
    sales=m.melt(id_vars=['period'],value_vars=['gmv','forecast_gmv'],var_name='series',value_name='value').dropna()
    sales['series']=sales.series.map({'gmv':'Actual GMV','forecast_gmv':'Rolling forecast'})
    confusion=pd.DataFrame([{'actual':a,'decision':b,'count':d['test'][k]} for a,b,k in [('Fraud','Flagged','tp'),('Legitimate','Flagged','fp'),('Fraud','Passed','fn'),('Legitimate','Passed','tn')]])
    pr=pd.DataFrame(d['pr_curve']);pr['point_order']=range(len(pr))
    tiers=pd.DataFrame(d['tiers']);tiers['risk_order']=['1 Low','2 Medium','3 High']
    lab=pd.DataFrame(d['threshold_lab']);lab['budget_label']=lab.budget.map(lambda x:f'{x*100:02.0f}%')
    roi_curve=pd.DataFrame([dict(prevention_grid=i/20,captured_fraud_gmv=d['test']['captured_fraud_gmv'],flagged=d['test']['flagged'],false_positives=d['test']['fp']) for i in range(21)])
    frames={'summary':pd.DataFrame([summary]),'monthly':m,'sales':sales,'confusion':confusion,'pr_curve':pr,
        'importance':pd.DataFrame(d['model']['importance']),'risk_tiers':tiers,'validation':lab,'roi_curve':roi_curve}
    for frame in frames.values():
        frame['DataMode']='SYNTHETIC';frame['DataStatus']=status;frame['RefreshedAt']=d['built_at']
    return frames

def make_hyper(frame,path,endpoint):
    from tableauhyperapi import Connection,CreateMode,TableDefinition,TableName,SqlType,Inserter
    temp=path.with_suffix('.tmp.hyper');temp.unlink(missing_ok=True)
    kinds={}
    for k in frame:
        if pd.api.types.is_integer_dtype(frame[k]):kinds[k]=SqlType.big_int()
        elif pd.api.types.is_numeric_dtype(frame[k]):kinds[k]=SqlType.double()
        elif pd.api.types.is_bool_dtype(frame[k]):kinds[k]=SqlType.bool()
        else:kinds[k]=SqlType.text()
    definition=TableDefinition(TableName('Extract','Extract'),[TableDefinition.Column(k,v) for k,v in kinds.items()])
    with Connection(endpoint,str(temp),CreateMode.CREATE_AND_REPLACE) as c:
        c.catalog.create_schema('Extract');c.catalog.create_table(definition)
        with Inserter(c,definition) as insert:
            values=frame.astype(object).where(pd.notna(frame),None)
            insert.add_rows(values.itertuples(index=False,name=None));insert.execute()
    temp.replace(path)

def export_tableau(result,root=ROOT,status='ready',hyper=True):
    folder=root/'tableau/Data';folder.mkdir(parents=True,exist_ok=True)
    frames=tables(result,status)
    q=root/'exports/quality_issues.csv'
    if q.exists():
        f=pd.read_csv(q);f['issue']=f.reason.str.replace('_',' ').str.title();f['DataStatus']=status;f['RefreshedAt']=result['built_at'];frames['quality']=f
    manifest={}
    for name,df in frames.items():
        temp=folder/f'{name}.tmp';df.to_csv(temp,index=False);temp.replace(folder/f'{name}.csv')
        manifest[name]=[dict(name=k,type='integer' if pd.api.types.is_integer_dtype(df[k]) else 'real' if pd.api.types.is_numeric_dtype(df[k]) else 'boolean' if pd.api.types.is_bool_dtype(df[k]) else 'string') for k in df]
    (root/'tableau/data_dictionary.json').write_text(json.dumps(manifest,indent=2))
    if hyper:
        from tableauhyperapi import HyperProcess,Telemetry
        with HyperProcess(Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU) as process:
            for name,df in frames.items():make_hyper(df,folder/f'{name}.hyper',process.endpoint)
    workbook=root/'tableau/Ticketmaster Fraud Detection Demo.twb'
    if workbook.exists() and hyper:package(root)
    return frames

def package(root=ROOT):
    folder=root/'tableau';target=folder/'Ticketmaster Fraud Detection Demo.twbx';tmp=target.with_suffix('.tmp')
    with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as z:
        z.write(folder/'Ticketmaster Fraud Detection Demo.twb','Ticketmaster Fraud Detection Demo.twb')
        for p in sorted((folder/'Data').glob('*')):
            if p.suffix in ['.csv','.hyper']:z.write(p,'Data/'+p.name)
    tmp.replace(target)
