# 从这里开始：Ticketmaster 四条简历的完整重建

交付标准已落实为 SQL 清洗 → pandas 整理 → Python 建模/分析 → 原生 Tableau。全部数据是独立模拟数据，不含公司或客户记录。

## 先运行一次成品

1. 双击项目根目录 `rebuild.command`。它执行完整清洗、整理、模型训练、数据导出和工作簿生成。
2. 用 Tableau Public 桌面版打开 `tableau/Ticketmaster Fraud Detection Demo.twbx`。四个 dashboard 的名字从 01 到 04，分别对应四条 bullet。
3. 如果要探索网页和自动 replay，再双击 `start.command`。网页是辅助检查工具；原生可编辑图表在 Tableau 中。

| 简历条目 | 练习与解释 | SQL | pandas / Python | 原生 dashboard |
|---|---|---|---|---|
| 1：自动分析销售、参与、欺诈 | [01_sales_automation.md](01_sales_automation.md) | 01_cleaning、02_sales_engagement | prepare、monthly_reports | 01 Sales and automation |
| 2：梯度提升风险模型 | [02_gradient_boosting.md](02_gradient_boosting.md) | features.sql | prepare、train、build | 02 Model diagnostics |
| 3：不平衡、Recall、风险分层 | [03_risk_policy.md](03_risk_policy.md) | 03_label_quality、04_risk_tiers | split、select_threshold、metrics | 03 Risk policy and exposure |
| 4：监控、预测偏差、ROI | [04_tableau_roi.md](04_tableau_roi.md) | 05_roi_inputs | monthly_reports、scenario、tableau_data | 04 Scenario and ROI |

## 推荐练习方法

每条先读业务问题，再独立写 SQL；用 pandas 复算并对账；读模型代码并手算一组指标；最后在 Tableau 新建一张相同图。各指南附命令、预期值和解释题。不要把“看过代码”当成“能够自己重建”。

模型共享是合理的：Bullet 2 训练分类器，Bullet 3 用同一分类器制定审核策略，Bullet 4 将结果转为经济情景。每一条都有完整数据路径与自己的分析产物。

简历中的原始提升比例、大金额和工时节省不会由模拟数据强行验证。当前模型召回率偏低，结果如实保留，可用来练习如何诊断与设计下一轮评估。
