# Bullet 3 — 不平衡类别、审核容量与风险分层

对应简历第三条：3–5% fraud class，prioritize recall，Low/Medium/High risk，风险金额识别。

## 完整运行路径

1. **SQL**：`sql/03_label_quality.sql` 检查成熟标签分布和清洗对账。模型完成后，对 `data/analytics.sqlite` 运行 `sql/04_risk_tiers.sql`。
2. **pandas**：整理标签覆盖、cohort、阈值表和分层汇总。分类模型的输出写入 `data/prepared/scored_transactions.csv`；该文件包含训练、验证、测试标签，评估前必须筛选 cohort。
3. **Python model / policy**：沿用第二条训练好的模型。在七月验证集上选择满足 5% 审核占比上限的最高 Recall 策略；同分交易一起处理，不拆开凑容量。测试使用固定阈值。
4. **Tableau**：**03 Risk policy and exposure**，查看测试审核量、已识别/遗漏欺诈 GMV、风险层级和验证容量曲线。

```bash
.venv/bin/python3 run_pipeline.py --stage model
.venv/bin/python3 run_pipeline.py --stage tableau
```

## 分步骤练习

- SQL：按 `cohort='Test'` 分组，输出每个 tier 的笔数、总 GMV、正例数和正例 GMV；核对总笔数为 818。
- pandas：用同一筛选再 `groupby('tier')`，与 SQL 一一核对。加入分母为零的情景，指标应保持缺失或 n/a。
- Python：先看 All legitimate baseline 的 95.1% Accuracy 与 0 Recall，再手算模型混淆矩阵。使用网页中的 validation capacity 滑杆对比 5%、10%、20%，记录新增审核带来的 Recall 与 Precision 变化。
- Tableau：在 Test transactions by risk tier worksheet 添加一个 tier filter，验证它改变的是该 worksheet 的层级视图。观察其他数据源 KPI 为什么没有被自动过滤；不要把未连通的事实表误认为同步联动。

## 预期结果

固定高风险阈值约 0.0712；测试实际审核 36/818≈4.4%，不会因为验证预算是 5% 就保证测试或每天都恰好 5%。

十月已识别欺诈 GMV=$371.15；遗漏欺诈 GMV=$5,521.14。它们是模拟的票券成交额，不是平台营收，也不是已实现保护收入。Medium band 为监控用启发式阈值，不是单独验证过的干预策略。

同一分类模型可服务多条业务描述；不需要为了每条 bullet 再训练一个相同模型。每条要有自己的 SQL/pandas 检查与 Tableau 产物。

## 关于 $1.2M

本次数据不会刻意制造 $1.2M 年化结果。原简历该数字需要原项目的风险口径、观察期、年化和业务证据。本练习用于重新掌握识别、度量和解释过程。

## 你应该能解释

为什么 Recall 优先也不能忽略 Precision？5% 欺诈率和 5% 审核量有什么区别？固定 score threshold 与固定 top-k 审核有什么区别？风险等级为何不是欺诈事实？
