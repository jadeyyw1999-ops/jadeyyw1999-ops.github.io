# Bullet 2 — 时间特征、pandas 特征矩阵与梯度提升模型

对应简历第二条：gradient-boosting transaction risk-scoring model；account age、seven-day purchase velocity、chargeback history。

## 完整运行路径

1. **SQL**：先清洗，再执行 `sql/features.sql`。每笔交易一行，构造账户年龄、七天交易次数和当时已知的历史拒付次数。
2. **pandas**：`prepare()` 将数值列明确转为 int64/float64，标签保持 Int64 nullable，时间标准化。结果标签在 pandas 中合并，不能自动落入模型输入。
3. **Python model**：`pipeline.py` 的 `FEATURES` 明确限定六项输入。`train()` 实际拟合 GradientBoostingClassifier，保存 `models/gradient_boosting.joblib` 与 model card。
4. **Tableau**：**02 Model diagnostics**，包含训练行数、AP、Recall、Precision、PR 曲线、混淆矩阵和验证集 permutation importance。

```bash
.venv/bin/python3 run_pipeline.py --stage all --retrain
```

## 时间设计与答案

| 阶段 | 交易发生时间 | 标签必须在什么时候前可见 | 行数 |
|---|---|---|---:|
| Train | 1–4 月 | 7 月 1 日 | 3,220 |
| Validation | 7 月 | 10 月 1 日 | 846 |
| Test | 10 月 | 2026 年 1 月 1 日 | 818 |

标签需要 60 天完整观察。5–6 月和 8–9 月是等待间隔；这些交易仍可作为当时已知的历史特征来源。同一账户可能跨时间段出现，这不是完全新客户泛化测试。

## 分步骤练习

- SQL：挑一笔交易，列出它之前七天的全部交易。窗口是 `[t−7 days,t)`，当前交易与同一时刻的交易都不计入。再列出 chargeback_at 严格早于 t 的拒付事件。
- pandas：读取 `data/prepared/features.csv` 时，分别打印 dtype、缺失标签数和 cohort 行数。标签缺失 1,708 笔，不能 `fillna(0)`。先看源代码如何保留 nullable，再自行实现。
- Python：区分 `X=...FEATURES` 与 `y=fraud_label`；解释为何 label_available_at 与未来 chargeback_at 不进入 X。检查模型 random_state 和保存的训练 signature。
- Tableau：打开 Precision recall curve worksheet，检查两轴为 recall/precision，Path 为 point_order。打开 Test confusion matrix，核对 3、33、37、745 四个单元格。再复制一张图，练习 tooltip 与格式设置。

## 指标与限制

固定十月测试集：Recall=3/40=7.5%；Precision=3/36≈8.3%；AP≈0.073。模型表现较弱，不能包装成已具备部署质量。PR 曲线不是 ROC 曲线；AP 也不是对 PR 曲线做梯形积分。

Permutation importance 使用验证集并保留负值。负值可能反映噪声或泛化不足，不等于“该特征有反向因果作用”。风险分数未验证校准，不能直接当成准确的欺诈概率。

## 你应该能解释

什么是梯度提升？为何当前数据可以得到低 Recall？如何判断是特征不足、正例太少还是策略容量太小？如何在不继续污染十月测试集的前提下设计后续改进实验？
