# Bullet 1 — SQL / pandas 自动化分析销售、参与和欺诈

对应简历第一条：automated SQL- and Python-based analyses across fraud detection, user engagement and sales performance。

## 完整运行路径

1. **SQL 清洗**：`sql/01_cleaning.sql`。数据源 `data/raw.sqlite`；结果 `data/transactions.sqlite`，包括四张 clean 表、`quarantine` 和 `cleaning_audit`。
2. **pandas 整理**：`stages/prepare.py`。带 `validate='one_to_one'` 的标签合并、UTC 日期、金额单位、nullable Int64 标签、account-month 粒度的重复购买、月度汇总与 SQL 对账。
3. **Python model**：`monthly_reports()` 使用 `gmv.shift(1).rolling(3).mean()` 预测下一个月；`pipeline.py` 执行分类模型和监控指标。预测只使用较早月份。
4. **Tableau**：打开原生工作簿的 **01 Sales and automation**，查看成交额、清洗后交易数、成熟标签、隔离记录、销售预测、重复购买和成熟欺诈率。

从项目目录运行：

```bash
.venv/bin/python3 run_pipeline.py --stage sql
.venv/bin/python3 run_pipeline.py --stage pandas
.venv/bin/python3 run_pipeline.py --stage all
```

## 先做练习，再看答案

- SQL：运行 `sql/02_sales_engagement.sql`。先按 account-month 统计购买次数，再按月计算重复购买买家比例。不要将每笔交易直接当成一个买家。
- pandas：用 `groupby(['month','account_id']).size()` 重写同一指标，再与 SQL 做一对一 merge 检查结果。
- 模型：手算四月的预测值，应等于一月至三月成交额的平均。把十二月成交额改大，仅在复制的 DataFrame 中操作，检查十二月预测是否改变。
- Tableau：进入 Monthly sales and rolling forecast worksheet，指出 Columns、Rows、Marks 的 Color 分别放什么。再从头新建同样一张图并与成品比较。

## 预期检查点

有效交易 10,000 笔；成熟标签 8,292 笔；隔离记录共 36 条。隔离记录来自四张 raw 表，不能把 36 都当成坏交易。交易 raw 10,013 = clean 10,000 + rejected 13。

`monthly_sql_control` 金额以美分存储；pandas/BI 金额是 USD，两个层级需要乘除 100 后对账。成交额是 ticket GMV，不是平台收入。重复购买比例仅描述行为，不证明留存增长或原简历中的 5% 提升。

## 你应该能解释

为什么分开 raw 与 clean？为什么坏记录不直接删除？为什么 merge 会放大金额？为什么最近月的欺诈率要看标签覆盖？如何验证自动化报表一致，而不是仅看到刷新时间变化？
