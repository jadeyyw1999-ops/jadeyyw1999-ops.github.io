# Bullet 4 — Tableau 监控、预测偏差和 ROI 情景

对应简历第四条：Tableau monitoring dashboards、forecast variance、scenario/ROI、减少手工报表。

## 完整运行路径

1. **SQL**：对 `data/analytics.sqlite` 运行 `sql/05_roi_inputs.sql`。只筛选 `cohort='Test'`，得到送审笔数、误报笔数和已识别欺诈 GMV。
2. **pandas**：BI marts 整理在 `stages/tableau_data.py`。月度、风险层级、PR 点、混淆矩阵各自保持明确粒度，每张 worksheet 使用单一事实来源，避免多对多月份连接。
3. **Python model**：`scenario()` 的经济模型；销售预测在 `monthly_reports()`。这两者与分类模型职责不同，都是可复现的业务建模。
4. **Tableau**：**04 Scenario and ROI**，五个原生参数、五个 KPI 与防止成功率敏感性曲线。**01 Sales and automation** 也包含实际/预测销售监控。

## 运行与打开

双击项目根目录 `rebuild.command` 可完整重建。随后在 Tableau Public 桌面版通过 File → Open 打开：

`tableau/Ticketmaster Fraud Detection Demo.twbx`

使用本地 File → Save / Save As 保存个人修改；不要使用 Save to Tableau Public。原生定义也保存在 `.twb`，与 `Data/` 文件夹一同保留即可。

这是本地学习项目，未发布到云端。运行中的 Python 服务可更新 Hyper 和 TWBX 文件，但当前已打开的 TWBX 是打开时的本地快照；重开它以查看最新打包数据，不应把文件自动更新理解成 Tableau 画布会被服务自动推送刷新。

## 参数与公式

- Avoidable loss = identified fraud GMV × prevention × severity。
- Review cost = flagged transactions × review cost per transaction。
- Friction cost = legitimate flagged × friction rate × cost per friction event。
- Net value = avoidable loss − review cost − friction cost。
- ROI = net value / (review cost + friction cost)，分母为零时为空。

原生 Tableau 计算字段完整保存在 `tableau/calculated_fields.json`，能与 Python 对照。

## 分步骤练习

1. SQL：确认输入为 flagged=36，false positives=33，identified fraud GMV=371.15。
2. pandas：读取 `tableau/Data/summary.csv`，与 SQL 的三个值比较。月度表与混淆矩阵不要按月份直接 join。
3. Python：默认 prevention=70%、severity=100%、每笔 review=$2、friction=3%、每次摩擦=$20。手算避免损失 259.805、review=72、friction=19.8、净值=168.005。
4. Tableau：把 Prevention success 改成 0%，确认 Avoidable loss 为 $0、Net value 约 -$92、ROI=-100%。其他成本不应一起消失。恢复 70%。
5. 在 Tableau 从头建立一个参数、一个计算字段和一张 KPI worksheet，再和成品比较依赖关系。不要只改页面上的静态标题数字。
6. 点击网页 Data operations → Replay，等待完成全链路更新。运行 `run_pipeline.py --stage tableau` 或重开更新后的 TWBX，核对交易数增加且原十月测试指标不变。最后 Restore。

## 解释自动化

输入是 `data/raw.sqlite`。文件检测 → SQL 清洗/隔离 → pandas 类型/合并/报表 → 冻结模型评分 → CSV/Hyper/TWBX 更新。需要重新训练时显式使用 `--retrain`。

本次运行耗时记录在 `exports/run_report.json`。它不是原项目“每周节省五小时”的证据；原项目节省需要有人工流程与自动流程的工时对比。
