"""Point-in-time SQL features, chronological evaluation and frozen-model scoring."""
from __future__ import annotations
import csv, hashlib, json, math, sqlite3
from pathlib import Path
from datetime import datetime, timezone, timedelta
import joblib
import numpy as np
import sklearn
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.inspection import permutation_importance
from sklearn.metrics import average_precision_score, precision_recall_curve

ROOT=Path(__file__).resolve().parent
FEATURES=['account_age_days','purchase_count_7d','prior_chargeback_count','amount','country_mismatch','device_code']
NAMES=['Account age','7-day purchase velocity','Prior chargebacks','Transaction amount','Country mismatch','Device type']

def now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')
def read_config(root=ROOT):
    c=json.loads((root/'config.json').read_text())
    if c['dataset']!='SYNTHETIC' or c['as_of']!='2026-01-01 00:00:00': raise ValueError('This demo requires the labeled synthetic snapshot at 2026-01-01.')
    if not 2<=float(c['watch_seconds'])<=60: raise ValueError('Watch interval must be 2–60 seconds.')
    if not 0<float(c['validation_review_budget'])<=.5: raise ValueError('Invalid review budget.')
    return c

def features(root=ROOT):
    from stages.prepare import prepare,records
    return records(prepare(root))

def matrix(rows):return np.array([[r[f] for f in FEATURES] for r in rows],dtype=float)
def split(rows,name):
    bounds={'train':('2025-01-01','2025-05-01','2025-07-01'),'validation':('2025-07-01','2025-08-01','2025-10-01'),'test':('2025-10-01','2025-11-01','2026-01-01')}
    lo,hi,cut=bounds[name]
    return [r for r in rows if lo<=r['transaction_at']<hi and r['fraud_label'] is not None and r['label_available_at']<cut]

def metrics(rows,threshold=None,predictions=None):
    y=np.array([r['fraud_label'] for r in rows],int)
    scores=np.array([r.get('score',0) for r in rows])
    p=np.array(predictions,bool) if predictions is not None else scores>=threshold
    tp=int(np.sum(p&(y==1)));fp=int(np.sum(p&(y==0)));fn=int(np.sum(~p&(y==1)));tn=int(np.sum(~p&(y==0)))
    n=len(rows);fraud=int(np.sum(y));flagged=int(np.sum(p))
    return dict(n=n,fraud=fraud,prevalence=fraud/n if n else 0,flagged=flagged,review_rate=flagged/n if n else 0,tp=tp,fp=fp,fn=fn,tn=tn,
        recall=tp/fraud if fraud else None,precision=tp/flagged if flagged else None,accuracy=(tp+tn)/n if n else 0,
        ap=float(average_precision_score(y,scores)) if fraud else None,
        flagged_gmv=sum(r['amount'] for r,a in zip(rows,p) if a),
        captured_fraud_gmv=sum(r['amount'] for r,a in zip(rows,p) if a and r['fraud_label']==1),
        missed_fraud_gmv=sum(r['amount'] for r,a in zip(rows,p) if not a and r['fraud_label']==1))

def select_threshold(rows,budget):
    # Maximize validation recall subject to the validation review-share constraint.
    # Equal scores are kept together. Never silently break ties to meet a capacity target.
    candidates=sorted(set([r['score'] for r in rows]+[1.000001]))
    feasible=[(metrics(rows,t),t) for t in candidates if sum(r['score']>=t for r in rows)/len(rows)<=budget]
    m,t=max(feasible,key=lambda x:((x[0]['recall'] or 0),x[0]['flagged'],-x[1]))
    return t,m

def train(root=ROOT):
    config=read_config(root);rows=features(root)
    tr,va=split(rows,'train'),split(rows,'validation')
    if not tr or not va or len({r['fraud_label'] for r in tr})<2 or len({r['fraud_label'] for r in va})<2:raise ValueError('Training and validation require both target classes')
    model=GradientBoostingClassifier(n_estimators=120,max_depth=2,min_samples_leaf=40,learning_rate=.04,subsample=.85,random_state=42)
    model.fit(matrix(tr),[r['fraud_label'] for r in tr])
    for r,s in zip(va,model.predict_proba(matrix(va))[:,1]):r['score']=float(s)
    threshold,val=select_threshold(va,config['validation_review_budget'])
    perm=permutation_importance(model,matrix(va),[r['fraud_label'] for r in va],scoring='average_precision',n_repeats=4,random_state=42,n_jobs=1)
    meta=dict(trained_at=now(),sklearn_version=sklearn.__version__,algorithm='GradientBoostingClassifier',features=FEATURES,
        high_threshold=threshold,medium_threshold=min(config['medium_risk_threshold'],threshold*.5),validation_budget=config['validation_review_budget'],
        train_count=len(tr),train_positives=sum(r['fraud_label'] for r in tr),validation_count=len(va),validation_result=val,
        importance=[dict(feature=f,name=n,ap_decrease=float(v)) for f,n,v in zip(FEATURES,NAMES,perm.importances_mean)],
        params=model.get_params(),split_policy='Train Jan–Apr; labels available before Jul 1. Validate Jul; labels before Oct 1. Test Oct; labels before Jan 1.',
        training_signature=hashlib.sha256(json.dumps([{k:r[k] for k in FEATURES+['transaction_id','fraud_label']} for r in tr],sort_keys=True).encode()).hexdigest()[:16])
    (root/'models').mkdir(exist_ok=True)
    joblib.dump({'model':model,'metadata':meta},root/'models/gradient_boosting.joblib')
    (root/'models/model_card.json').write_text(json.dumps(meta,indent=2))
    return meta

def tier(score,meta):return 'High' if score>=meta['high_threshold'] else 'Medium' if score>=meta['medium_threshold'] else 'Low'

def scenario(test,inputs):
    limits={'review_cost':(0,100),'prevention_rate':(0,1),'loss_severity':(0,1),'friction_rate':(0,1),'friction_cost':(0,1000)}
    d={k:float(inputs[k]) for k in limits}
    if any(not math.isfinite(d[k]) or not lo<=d[k]<=hi for k,(lo,hi) in limits.items()):raise ValueError('Scenario inputs outside supported bounds')
    avoid=test['captured_fraud_gmv']*d['loss_severity']*d['prevention_rate']
    review=test['flagged']*d['review_cost'];friction=test['fp']*d['friction_rate']*d['friction_cost'];cost=review+friction
    return dict(inputs=d,avoided_loss=avoid,review_cost=review,friction_cost=friction,total_cost=cost,net_value=avoid-cost,roi=(avoid-cost)/cost if cost else None,
        basis='Retrospective October test-set illustration. Not realized protected revenue.')

def build(root=ROOT):
    config=read_config(root);rows=features(root)
    artifact=joblib.load(root/'models/gradient_boosting.joblib');model=artifact['model'];meta=artifact['metadata']
    if meta['features']!=FEATURES or meta['sklearn_version']!=sklearn.__version__:raise ValueError('Model/runtime mismatch. Run pipeline.py --train in this environment.')
    for r,s in zip(rows,model.predict_proba(matrix(rows))[:,1]):
        r['score']=float(s);r['tier']=tier(s,meta)
        r['label_mature']=r['fraud_label'] is not None and r['label_available_at']<config['as_of']
        if not r['label_mature']:r['fraud_label']=None
    tr,va,te=(split(rows,k) for k in ['train','validation','test'])
    import pandas as pd
    pd.DataFrame(rows).to_csv(root/'data/prepared/scored_transactions.csv',index=False)
    if not te or len({r['fraud_label'] for r in te})<2:raise ValueError('Test window requires both mature target classes')
    # The frozen model must still describe the exact original training features/labels.
    sig=hashlib.sha256(json.dumps([{k:r[k] for k in FEATURES+['transaction_id','fraud_label']} for r in tr],sort_keys=True).encode()).hexdigest()[:16]
    if sig!=meta['training_signature']:raise ValueError('Training history changed. Rebuild the model explicitly with pipeline.py --train.')
    test=metrics(te,meta['high_threshold']);val=metrics(va,meta['high_threshold'])
    baseline=metrics(te,predictions=[False]*len(te));baseline['ap']=test['prevalence']
    rules=metrics(te,predictions=[r['account_age_days']<30 or r['country_mismatch']==1 or r['prior_chargeback_count']>0 for r in te]);rules['ap']=None
    precision,recall,_=precision_recall_curve([r['fraud_label'] for r in te],[r['score'] for r in te])
    indices=np.unique(np.linspace(0,len(precision)-1,min(130,len(precision))).astype(int))
    curve=[dict(recall=float(recall[i]),precision=float(precision[i])) for i in indices]
    threshold_lab=[]
    for b in [.01,.02,.03,.05,.08,.10,.15,.20,.30]:
        t,m=select_threshold(va,b);threshold_lab.append(dict(budget=b,threshold=t,**m))
    from stages.prepare import monthly_reports
    import pandas as pd
    monthly=monthly_reports(pd.DataFrame(rows))
    tiers=[]
    for name in ['Low','Medium','High']:
        rs=[r for r in te if r['tier']==name]
        tiers.append(dict(tier=name,n=len(rs),gmv=sum(r['amount'] for r in rs),fraud=sum(r['fraud_label'] for r in rs),fraud_rate=sum(r['fraud_label'] for r in rs)/len(rs) if rs else None,captured_fraud_gmv=sum(r['amount'] for r in rs if r['fraud_label']==1)))
    latest=[r for r in rows if r['transaction_at']>='2025-11-01']
    queue=sorted(latest,key=lambda r:(-r['score'],r['transaction_id']))
    queue=[{k:r[k] for k in ['transaction_id','account_id','transaction_at','amount','score','tier','account_age_days','purchase_count_7d','prior_chargeback_count','country_mismatch','device_type']} for r in queue]
    revision=hashlib.sha256((root/('data/raw.sqlite' if (root/'data/raw.sqlite').exists() else 'data/transactions.sqlite')).read_bytes()+(root/'config.json').read_bytes()+(root/'models/gradient_boosting.joblib').read_bytes()).hexdigest()[:12]
    return dict(dataset='SYNTHETIC',title='Ticketmaster Fraud Detection Demo',as_of=config['as_of'],built_at=now(),revision=revision,
        model=meta,test=test,validation=val,baseline=baseline,rules=rules,pr_curve=curve,threshold_lab=threshold_lab,monthly=monthly,tiers=tiers,queue=queue,
        queue_summary=dict(n=len(queue),high=sum(r['tier']=='High' for r in queue),gmv=sum(r['amount'] for r in queue)),
        totals=dict(transactions=len(rows),mature=sum(r['label_mature'] for r in rows),fraud=sum(r['fraud_label'] or 0 for r in rows)),
        default_scenario=scenario(test,config['roi']),cleaning=json.loads((root/'data/clean_manifest.json').read_text()) if (root/'data/clean_manifest.json').exists() else None,checks=[
            dict(name='SQL cleaning and pandas reconciliation',detail='Raw rows = clean + quarantine; one-to-one label merge; SQL and pandas amounts agree'),
            dict(name='Transaction grain preserved',detail=f'{len(rows):,} unique transactions; feature joins reconcile'),
            dict(name='Point-in-time feature boundaries',detail='7-day history excludes the current transaction; chargebacks must be known before scoring'),
            dict(name='Delayed labels respected',detail='60-day observation window; unknown outcomes are never assigned to the non-fraud class'),
            dict(name='Frozen chronological evaluation',detail=f'{len(tr):,} train / {len(va):,} validation / {len(te):,} held-out test transactions'),
            dict(name='Synthetic provenance',detail='Independent learning data. No company or customer records.')])

def export(result,folder,status='ready'):
    folder.mkdir(exist_ok=True)
    tables={'monthly':result['monthly'],'risk_tiers':result['tiers'],'scored_queue':result['queue']}
    import pandas as pd
    analytics=sqlite3.connect(folder.parent/'data/analytics.sqlite')
    try:
        scored=pd.read_csv(folder.parent/'data/prepared/scored_transactions.csv')
        scored.to_sql('scored_transactions',analytics,if_exists='replace',index=False)
        pd.DataFrame(result['monthly']).to_sql('monthly_report',analytics,if_exists='replace',index=False)
        pd.DataFrame(result['threshold_lab']).to_sql('validation_policies',analytics,if_exists='replace',index=False)
    finally:analytics.close()
    for name,rows in tables.items():
        path=folder/f'{name}.csv';tmp=path.with_suffix('.tmp')
        labeled=[dict(DataMode='SYNTHETIC',DataStatus=status,RefreshedAt=result['built_at'],**r) for r in rows]
        with tmp.open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(labeled[0]));w.writeheader();w.writerows(labeled)
        tmp.replace(path)
    (folder/'metrics.json').write_text(json.dumps(dict(DataMode='SYNTHETIC',DataStatus=status,RefreshedAt=result['built_at'],test=result['test'],model=result['model']),indent=2))
    if result.get('cleaning') is not None:
        from stages.tableau_data import export_tableau
        export_tableau(result,folder.parent,status)

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--train',action='store_true');a=p.parse_args()
    if a.train or not (ROOT/'models/gradient_boosting.joblib').exists():train()
    r=build();export(r,ROOT/'exports')
    print(json.dumps(dict(dataset=r['dataset'],test=r['test'],high_threshold=r['model']['high_threshold']),indent=2))
