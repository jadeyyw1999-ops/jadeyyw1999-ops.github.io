-- BigQuery translation template. Replace PROJECT.DATASET with your own dataset.
-- This file is not executed by the local demo; no BigQuery project is connected.
WITH velocity AS (
 SELECT t.transaction_id, COUNT(h.transaction_id) AS purchase_count_7d
 FROM `PROJECT.DATASET.transactions` t
 LEFT JOIN `PROJECT.DATASET.transactions` h
   ON h.account_id=t.account_id
  AND h.transaction_at>=TIMESTAMP_SUB(t.transaction_at,INTERVAL 7 DAY)
  AND h.transaction_at<t.transaction_at
 GROUP BY t.transaction_id
), history AS (
 SELECT t.transaction_id, COUNT(e.transaction_id) AS prior_chargeback_count
 FROM `PROJECT.DATASET.transactions` t
 LEFT JOIN `PROJECT.DATASET.transactions` h ON h.account_id=t.account_id
 LEFT JOIN `PROJECT.DATASET.chargeback_events` e
   ON e.transaction_id=h.transaction_id AND e.chargeback_at<t.transaction_at
 GROUP BY t.transaction_id
)
SELECT t.transaction_id,t.account_id,t.transaction_at,t.amount_cents/100.0 AS amount,
 TIMESTAMP_DIFF(t.transaction_at,a.created_at,SECOND)/86400.0 AS account_age_days,
 v.purchase_count_7d,h.prior_chargeback_count,t.country_mismatch,t.device_type
FROM `PROJECT.DATASET.transactions` t
JOIN `PROJECT.DATASET.accounts` a USING(account_id)
JOIN velocity v USING(transaction_id)
JOIN history h USING(transaction_id);
