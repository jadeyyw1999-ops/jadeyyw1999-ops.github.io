-- Clean SQL reporting source: data/transactions.sqlite
-- A) Monthly row and monetary controls. Money here is integer cents.
SELECT * FROM monthly_sql_control ORDER BY month;

-- B) Account-month grain first, then monthly repeat-buyer share.
WITH buyer_month AS (
 SELECT substr(transaction_at,1,7) AS month,account_id,COUNT(*) purchases
 FROM transactions GROUP BY 1,2
)
SELECT month,COUNT(*) active_buyers,
 SUM(CASE WHEN purchases>=2 THEN 1 ELSE 0 END) repeat_buyers,
 1.0*SUM(CASE WHEN purchases>=2 THEN 1 ELSE 0 END)/COUNT(*) repeat_buyer_share
FROM buyer_month GROUP BY month ORDER BY month;
