-- Execute against a new clean database with the raw source attached as raw.
-- Only SQL performs normalization, row validation, deduplication and quarantine.
-- First valid ingestion wins a key. Rejected copies retain lineage and reason.
PRAGMA foreign_keys=ON;

-- SYNTHETIC learning data. Monetary values are integer USD cents.

CREATE TABLE accounts(account_id INTEGER PRIMARY KEY, created_at TEXT NOT NULL,
                          country TEXT NOT NULL);

CREATE TABLE chargeback_events(transaction_id INTEGER PRIMARY KEY REFERENCES transactions,
      chargeback_at TEXT NOT NULL);

CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);

CREATE TABLE outcomes(transaction_id INTEGER PRIMARY KEY REFERENCES transactions,
      fraud_label INTEGER NOT NULL CHECK(fraud_label IN(0,1)),
      label_available_at TEXT NOT NULL, chargeback_at TEXT);

CREATE TABLE transactions(transaction_id INTEGER PRIMARY KEY,
      account_id INTEGER NOT NULL REFERENCES accounts, transaction_at TEXT NOT NULL,
      amount_cents INTEGER NOT NULL CHECK(amount_cents>0), device_type TEXT NOT NULL,
      country_mismatch INTEGER NOT NULL CHECK(country_mismatch IN(0,1)));

CREATE INDEX tx_account_time ON transactions(account_id,transaction_at);


INSERT INTO metadata SELECT * FROM raw.metadata;
CREATE TABLE quarantine(source_table TEXT,ingest_id INTEGER,business_key TEXT,reason TEXT,payload TEXT);
CREATE TABLE cleaning_audit(source_table TEXT PRIMARY KEY,raw_rows INTEGER,clean_rows INTEGER,rejected_rows INTEGER);


CREATE TEMP TABLE stage_accounts AS
WITH normalized AS (SELECT ingest_id,TRIM(account_id) AS account_id,
 TRIM(created_at) AS created_at,
 UPPER(TRIM(country)) AS country FROM raw.raw_accounts),
validated AS (SELECT *,CASE WHEN NOT COALESCE(((account_id IS NOT NULL AND account_id<>'' AND account_id NOT GLOB '*[^0-9]*' AND CAST(account_id AS INTEGER)>0)),0) THEN 'INVALID_ACCOUNT_ID'
WHEN NOT COALESCE(((created_at IS NOT NULL AND length(created_at)=19 AND datetime(created_at) IS NOT NULL AND datetime(created_at)=created_at)),0) THEN 'INVALID_CREATED_AT'
WHEN NOT COALESCE((country IN ('US','CA','GB')),0) THEN 'INVALID_COUNTRY' ELSE NULL END AS invalid_reason FROM normalized),
ranked AS (SELECT *,SUM(CASE WHEN invalid_reason IS NULL THEN 1 ELSE 0 END) OVER(PARTITION BY account_id ORDER BY ingest_id) AS valid_rank FROM validated)
SELECT *,CASE WHEN invalid_reason IS NOT NULL THEN invalid_reason WHEN valid_rank>1 THEN 'DUPLICATE_KEY' ELSE NULL END AS rejection_reason FROM ranked;
INSERT INTO accounts(account_id,created_at,country) SELECT CAST(account_id AS INTEGER),created_at,country FROM stage_accounts WHERE rejection_reason IS NULL;
INSERT INTO quarantine SELECT 'accounts',s.ingest_id,s.account_id,s.rejection_reason,
 json_object('account_id',r.account_id,'created_at',r.created_at,'country',r.country)
FROM stage_accounts s JOIN raw.raw_accounts r USING(ingest_id) WHERE s.rejection_reason IS NOT NULL;
INSERT INTO cleaning_audit SELECT 'accounts',(SELECT COUNT(*) FROM raw.raw_accounts),(SELECT COUNT(*) FROM accounts),(SELECT COUNT(*) FROM quarantine WHERE source_table='accounts');


CREATE TEMP TABLE stage_transactions AS
WITH normalized AS (SELECT ingest_id,TRIM(transaction_id) AS transaction_id,
 TRIM(account_id) AS account_id,
 TRIM(transaction_at) AS transaction_at,
 TRIM(amount_cents) AS amount_cents,
 LOWER(TRIM(device_type)) AS device_type,
 TRIM(country_mismatch) AS country_mismatch FROM raw.raw_transactions),
validated AS (SELECT *,CASE WHEN NOT COALESCE(((transaction_id IS NOT NULL AND transaction_id<>'' AND transaction_id NOT GLOB '*[^0-9]*' AND CAST(transaction_id AS INTEGER)>0)),0) THEN 'INVALID_TRANSACTION_ID'
WHEN NOT COALESCE(((account_id IS NOT NULL AND account_id<>'' AND account_id NOT GLOB '*[^0-9]*' AND CAST(account_id AS INTEGER)>0)),0) THEN 'INVALID_ACCOUNT_ID'
WHEN NOT COALESCE(((amount_cents IS NOT NULL AND amount_cents<>'' AND amount_cents NOT GLOB '*[^0-9]*' AND CAST(amount_cents AS INTEGER)>0)),0) THEN 'INVALID_AMOUNT_CENTS'
WHEN NOT COALESCE(((transaction_at IS NOT NULL AND length(transaction_at)=19 AND datetime(transaction_at) IS NOT NULL AND datetime(transaction_at)=transaction_at)),0) THEN 'INVALID_TRANSACTION_AT'
WHEN NOT COALESCE((transaction_at<'2026-01-01 00:00:00'),0) THEN 'AFTER_SNAPSHOT'
WHEN NOT COALESCE((device_type IN ('web','ios','android')),0) THEN 'INVALID_DEVICE'
WHEN NOT COALESCE((country_mismatch IN ('0','1')),0) THEN 'INVALID_MISMATCH'
WHEN NOT COALESCE((EXISTS(SELECT 1 FROM accounts a WHERE a.account_id=CAST(normalized.account_id AS INTEGER))),0) THEN 'MISSING_ACCOUNT'
WHEN NOT COALESCE((transaction_at>=(SELECT created_at FROM accounts a WHERE a.account_id=CAST(normalized.account_id AS INTEGER))),0) THEN 'TRANSACTION_BEFORE_ACCOUNT' ELSE NULL END AS invalid_reason FROM normalized),
ranked AS (SELECT *,SUM(CASE WHEN invalid_reason IS NULL THEN 1 ELSE 0 END) OVER(PARTITION BY transaction_id ORDER BY ingest_id) AS valid_rank FROM validated)
SELECT *,CASE WHEN invalid_reason IS NOT NULL THEN invalid_reason WHEN valid_rank>1 THEN 'DUPLICATE_KEY' ELSE NULL END AS rejection_reason FROM ranked;
INSERT INTO transactions(transaction_id,account_id,transaction_at,amount_cents,device_type,country_mismatch) SELECT CAST(transaction_id AS INTEGER),CAST(account_id AS INTEGER),transaction_at,CAST(amount_cents AS INTEGER),device_type,CAST(country_mismatch AS INTEGER) FROM stage_transactions WHERE rejection_reason IS NULL;
INSERT INTO quarantine SELECT 'transactions',s.ingest_id,s.transaction_id,s.rejection_reason,
 json_object('transaction_id',r.transaction_id,'account_id',r.account_id,'transaction_at',r.transaction_at,'amount_cents',r.amount_cents,'device_type',r.device_type,'country_mismatch',r.country_mismatch)
FROM stage_transactions s JOIN raw.raw_transactions r USING(ingest_id) WHERE s.rejection_reason IS NOT NULL;
INSERT INTO cleaning_audit SELECT 'transactions',(SELECT COUNT(*) FROM raw.raw_transactions),(SELECT COUNT(*) FROM transactions),(SELECT COUNT(*) FROM quarantine WHERE source_table='transactions');


CREATE TEMP TABLE stage_outcomes AS
WITH normalized AS (SELECT ingest_id,TRIM(transaction_id) AS transaction_id,
 TRIM(fraud_label) AS fraud_label,
 TRIM(label_available_at) AS label_available_at,
 TRIM(chargeback_at) AS chargeback_at FROM raw.raw_outcomes),
validated AS (SELECT *,CASE WHEN NOT COALESCE(((transaction_id IS NOT NULL AND transaction_id<>'' AND transaction_id NOT GLOB '*[^0-9]*' AND CAST(transaction_id AS INTEGER)>0)),0) THEN 'INVALID_TRANSACTION_ID'
WHEN NOT COALESCE((fraud_label IN ('0','1')),0) THEN 'INVALID_TARGET'
WHEN NOT COALESCE(((label_available_at IS NOT NULL AND length(label_available_at)=19 AND datetime(label_available_at) IS NOT NULL AND datetime(label_available_at)=label_available_at)),0) THEN 'INVALID_LABEL_DATE'
WHEN NOT COALESCE((EXISTS(SELECT 1 FROM transactions t WHERE t.transaction_id=CAST(normalized.transaction_id AS INTEGER))),0) THEN 'MISSING_TRANSACTION'
WHEN NOT COALESCE((label_available_at>=datetime((SELECT transaction_at FROM transactions t WHERE t.transaction_id=CAST(normalized.transaction_id AS INTEGER)),'+60 days')),0) THEN 'IMMATURE_OBSERVATION_WINDOW'
WHEN NOT COALESCE((label_available_at<'2026-01-01 00:00:00'),0) THEN 'AFTER_SNAPSHOT'
WHEN NOT COALESCE((chargeback_at IS NULL OR ((chargeback_at IS NOT NULL AND length(chargeback_at)=19 AND datetime(chargeback_at) IS NOT NULL AND datetime(chargeback_at)=chargeback_at) AND chargeback_at>(SELECT transaction_at FROM transactions t WHERE t.transaction_id=CAST(normalized.transaction_id AS INTEGER)) AND chargeback_at<'2026-01-01 00:00:00')),0) THEN 'INVALID_CHARGEBACK_DATE' ELSE NULL END AS invalid_reason FROM normalized),
ranked AS (SELECT *,SUM(CASE WHEN invalid_reason IS NULL THEN 1 ELSE 0 END) OVER(PARTITION BY transaction_id ORDER BY ingest_id) AS valid_rank FROM validated)
SELECT *,CASE WHEN invalid_reason IS NOT NULL THEN invalid_reason WHEN valid_rank>1 THEN 'DUPLICATE_KEY' ELSE NULL END AS rejection_reason FROM ranked;
INSERT INTO outcomes(transaction_id,fraud_label,label_available_at,chargeback_at) SELECT CAST(transaction_id AS INTEGER),CAST(fraud_label AS INTEGER),label_available_at,chargeback_at FROM stage_outcomes WHERE rejection_reason IS NULL;
INSERT INTO quarantine SELECT 'outcomes',s.ingest_id,s.transaction_id,s.rejection_reason,
 json_object('transaction_id',r.transaction_id,'fraud_label',r.fraud_label,'label_available_at',r.label_available_at,'chargeback_at',r.chargeback_at)
FROM stage_outcomes s JOIN raw.raw_outcomes r USING(ingest_id) WHERE s.rejection_reason IS NOT NULL;
INSERT INTO cleaning_audit SELECT 'outcomes',(SELECT COUNT(*) FROM raw.raw_outcomes),(SELECT COUNT(*) FROM outcomes),(SELECT COUNT(*) FROM quarantine WHERE source_table='outcomes');


CREATE TEMP TABLE stage_chargeback_events AS
WITH normalized AS (SELECT ingest_id,TRIM(transaction_id) AS transaction_id,
 TRIM(chargeback_at) AS chargeback_at FROM raw.raw_chargeback_events),
validated AS (SELECT *,CASE WHEN NOT COALESCE(((transaction_id IS NOT NULL AND transaction_id<>'' AND transaction_id NOT GLOB '*[^0-9]*' AND CAST(transaction_id AS INTEGER)>0)),0) THEN 'INVALID_TRANSACTION_ID'
WHEN NOT COALESCE(((chargeback_at IS NOT NULL AND length(chargeback_at)=19 AND datetime(chargeback_at) IS NOT NULL AND datetime(chargeback_at)=chargeback_at)),0) THEN 'INVALID_CHARGEBACK_DATE'
WHEN NOT COALESCE((EXISTS(SELECT 1 FROM transactions t WHERE t.transaction_id=CAST(normalized.transaction_id AS INTEGER))),0) THEN 'MISSING_TRANSACTION'
WHEN NOT COALESCE((chargeback_at>(SELECT transaction_at FROM transactions t WHERE t.transaction_id=CAST(normalized.transaction_id AS INTEGER)) AND chargeback_at<'2026-01-01 00:00:00'),0) THEN 'INVALID_CHARGEBACK_TIMING' ELSE NULL END AS invalid_reason FROM normalized),
ranked AS (SELECT *,SUM(CASE WHEN invalid_reason IS NULL THEN 1 ELSE 0 END) OVER(PARTITION BY transaction_id ORDER BY ingest_id) AS valid_rank FROM validated)
SELECT *,CASE WHEN invalid_reason IS NOT NULL THEN invalid_reason WHEN valid_rank>1 THEN 'DUPLICATE_KEY' ELSE NULL END AS rejection_reason FROM ranked;
INSERT INTO chargeback_events(transaction_id,chargeback_at) SELECT CAST(transaction_id AS INTEGER),chargeback_at FROM stage_chargeback_events WHERE rejection_reason IS NULL;
INSERT INTO quarantine SELECT 'chargeback_events',s.ingest_id,s.transaction_id,s.rejection_reason,
 json_object('transaction_id',r.transaction_id,'chargeback_at',r.chargeback_at)
FROM stage_chargeback_events s JOIN raw.raw_chargeback_events r USING(ingest_id) WHERE s.rejection_reason IS NOT NULL;
INSERT INTO cleaning_audit SELECT 'chargeback_events',(SELECT COUNT(*) FROM raw.raw_chargeback_events),(SELECT COUNT(*) FROM chargeback_events),(SELECT COUNT(*) FROM quarantine WHERE source_table='chargeback_events');


CREATE VIEW monthly_sql_control AS
 SELECT substr(transaction_at,1,7)||'-01' AS month,COUNT(*) AS transactions,SUM(amount_cents) AS gmv_cents,COUNT(DISTINCT account_id) AS active_buyers
 FROM transactions GROUP BY 1;
