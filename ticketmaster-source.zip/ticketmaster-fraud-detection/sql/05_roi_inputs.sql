-- Model mart: SQL inputs to the economic model, at ONE held-out test window.
SELECT SUM(CASE WHEN tier='High' THEN 1 ELSE 0 END) flagged,
 SUM(CASE WHEN tier='High' AND fraud_label=0 THEN 1 ELSE 0 END) false_positives,
 SUM(CASE WHEN tier='High' AND fraud_label=1 THEN amount ELSE 0 END) identified_fraud_gmv,
 SUM(CASE WHEN tier<>'High' AND fraud_label=1 THEN amount ELSE 0 END) missed_fraud_gmv
FROM scored_transactions WHERE cohort='Test';

SELECT month,gmv,forecast_gmv,variance,variance_pct
FROM monthly_report ORDER BY month;
