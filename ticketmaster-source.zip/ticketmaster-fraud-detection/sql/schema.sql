-- SYNTHETIC learning data. Monetary values are integer USD cents.

CREATE TABLE accounts(account_id INTEGER PRIMARY KEY, created_at TEXT NOT NULL,
                          country TEXT NOT NULL);

CREATE TABLE chargeback_events(transaction_id INTEGER PRIMARY KEY REFERENCES transactions,
      chargeback_at TEXT NOT NULL);

CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);

CREATE TABLE outcomes(transaction_id INTEGER PRIMARY KEY REFERENCES transactions,
      fraud_label INTEGER NOT NULL CHECK(fraud_label IN(0,1)),
      label_available_at TEXT NOT NULL, chargeback_at TEXT);

CREATE TABLE transactions(transaction_id INTEGER PRIMARY KEY,
      account_id INTEGER NOT NULL REFERENCES accounts, transaction_at TEXT NOT NULL,
      amount_cents INTEGER NOT NULL CHECK(amount_cents>0), device_type TEXT NOT NULL,
      country_mismatch INTEGER NOT NULL CHECK(country_mismatch IN(0,1)));

CREATE INDEX tx_account_time ON transactions(account_id,transaction_at);
