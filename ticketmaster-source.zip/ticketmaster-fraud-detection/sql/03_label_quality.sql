-- Clean source: outcomes are LEFT joined; missing labels remain NULL.
SELECT substr(t.transaction_at,1,7) month,COUNT(*) transactions,
 COUNT(o.fraud_label) mature_labels,SUM(o.fraud_label) positives,
 1.0*SUM(o.fraud_label)/NULLIF(COUNT(o.fraud_label),0) mature_fraud_rate
FROM transactions t LEFT JOIN outcomes o USING(transaction_id)
GROUP BY 1 ORDER BY 1;

-- Reconciliation: every rejected raw record has an explicit reason.
SELECT * FROM cleaning_audit;
SELECT source_table,reason,COUNT(*) rejected_rows
FROM quarantine GROUP BY 1,2 ORDER BY rejected_rows DESC;
