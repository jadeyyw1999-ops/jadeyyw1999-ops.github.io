-- SQLite execution version. Every feature is observable strictly before scoring.
-- The lower velocity bound is inclusive; the current transaction is excluded.
SELECT t.transaction_id, t.account_id, t.transaction_at,
       t.amount_cents / 100.0 AS amount,
       MAX(0, julianday(t.transaction_at)-julianday(a.created_at)) AS account_age_days,
       (SELECT COUNT(*) FROM transactions h
        WHERE h.account_id=t.account_id
          AND h.transaction_at >= datetime(t.transaction_at,'-7 days')
          AND h.transaction_at < t.transaction_at) AS purchase_count_7d,
       (SELECT COUNT(*) FROM chargeback_events e
        JOIN transactions h ON h.transaction_id=e.transaction_id
        WHERE h.account_id=t.account_id AND e.chargeback_at<t.transaction_at) AS prior_chargeback_count,
       t.country_mismatch,
       CASE t.device_type WHEN 'ios' THEN 1 WHEN 'android' THEN 2 ELSE 0 END AS device_code,
       t.device_type
FROM transactions t JOIN accounts a ON a.account_id=t.account_id
ORDER BY t.transaction_at,t.transaction_id;
