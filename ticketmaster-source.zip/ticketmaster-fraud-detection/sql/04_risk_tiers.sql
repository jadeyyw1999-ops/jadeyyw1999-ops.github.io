-- Model mart: data/analytics.sqlite. Do not mix training and held-out performance.
SELECT tier,COUNT(*) transactions,SUM(amount) ticket_gmv,
 SUM(fraud_label) confirmed_synthetic_fraud,
 1.0*SUM(fraud_label)/COUNT(*) fraud_rate,
 SUM(CASE WHEN fraud_label=1 THEN amount ELSE 0 END) confirmed_fraud_gmv
FROM scored_transactions WHERE cohort='Test'
GROUP BY tier ORDER BY CASE tier WHEN 'Low' THEN 1 WHEN 'Medium' THEN 2 ELSE 3 END;

SELECT budget,threshold,recall,precision,review_rate
FROM validation_policies ORDER BY budget;
