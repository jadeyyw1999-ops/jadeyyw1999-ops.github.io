"""One entry point for the complete SQL → pandas → model → Tableau rebuild."""
from pathlib import Path
import argparse,json,time
from pipeline import ROOT,train,build,export
from stages.seed_raw import seed
from stages.prepare import clean,prepare
from stages.build_tableau import build as workbook

def main():
    p=argparse.ArgumentParser();p.add_argument('--stage',choices=['sql','pandas','model','tableau','all'],default='all');p.add_argument('--retrain',action='store_true');p.add_argument('--reset-synthetic',action='store_true');a=p.parse_args()
    start=time.perf_counter()
    if a.reset_synthetic or not (ROOT/'data/raw.sqlite').exists():seed()
    audit=clean()
    if a.stage=='sql':print(json.dumps(audit,indent=2));return
    df=prepare()
    if a.stage=='pandas':print(df.groupby('cohort').size().to_string());print('Prepared features:',ROOT/'data/prepared/features.csv');return
    if a.retrain or not (ROOT/'models/gradient_boosting.joblib').exists():train()
    result=build();export(result,ROOT/'exports')
    if a.stage in ['tableau','all']:workbook()
    seconds=time.perf_counter()-start
    report=dict(status='ready',dataset='SYNTHETIC',rows=len(df),quarantined=audit['quarantined'],test=result['test'],seconds=seconds,tableau='tableau/Ticketmaster Fraud Detection Demo.twbx')
    (ROOT/'exports/run_report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':main()
