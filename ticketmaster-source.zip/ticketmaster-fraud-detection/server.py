"""Loopback-only server, file monitor and synthetic source replay."""
from __future__ import annotations
import argparse,copy,json,mimetypes,shutil,sqlite3,threading,time,webbrowser
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
from pipeline import ROOT,build,export,read_config,scenario,now,train

class Engine:
    def __init__(self,root=ROOT):
        self.root=root;self.lock=threading.RLock();self.stop=threading.Event();self.good=None;self.signature=None;self.error=None;self.status='loading';self.logs=[];self.last_attempt=None
        try:self.good=json.loads((root/'.state/latest.json').read_text())
        except (OSError,ValueError):pass
    def paths(self):return [self.root/p for p in ['data/raw.sqlite','config.json','sql/01_cleaning.sql','sql/features.sql','models/gradient_boosting.joblib']]
    def sig(self):return [(p.name,p.stat().st_size,p.stat().st_mtime_ns) for p in self.paths()]
    def log(self,event,detail):self.logs.insert(0,dict(time=now(),event=event,detail=detail));self.logs=self.logs[:25]
    def refresh(self,force=False):
        with self.lock:
            try:
                sig=self.sig()
                if not force and sig==self.signature:return False
                self.signature=sig;self.last_attempt=now();r=build(self.root)
                if sig!=self.sig():raise ValueError('Source changed during ingestion. Waiting for a stable save.')
                previous=self.good
                self.good=r;self.error=None;self.status='ready'
                export(r,self.root/'exports')
                (self.root/'.state').mkdir(exist_ok=True)
                temp=self.root/'.state/latest.tmp';temp.write_text(json.dumps(r,allow_nan=False));temp.replace(self.root/'.state/latest.json')
                self.log('UPDATED' if not previous or r['revision']!=previous['revision'] else 'VERIFIED','SQL cleaned; pandas reconciled; frozen model scored; Tableau extracts and exports refreshed.')
                return True
            except Exception as e:
                self.error=str(e)[:220];self.status='stale' if self.good else 'unavailable';self.log('FAILED',self.error)
                if self.good:
                    try:export(self.good,self.root/'exports',self.status)
                    except OSError:pass
                return False
    def view(self):
        with self.lock:
            try:seconds=read_config(self.root)['watch_seconds']
            except Exception:seconds=5
            return dict(data=copy.deepcopy(self.good),runtime=dict(status=self.status,error=self.error,last_attempt=self.last_attempt,watch_seconds=seconds,logs=copy.deepcopy(self.logs)))
    def watch(self):
        while not self.stop.is_set():
            self.refresh()
            try:seconds=read_config(self.root)['watch_seconds']
            except Exception:seconds=5
            self.stop.wait(seconds)
    def replay(self,restore=False):
        with self.lock:
            path=self.root/'data/raw.sqlite'
            if restore:
                tmp=path.with_suffix('.tmp');shutil.copyfile(self.root/'data/raw_original.sqlite',tmp);tmp.replace(path)
                self.log('SOURCE SAVED','Synthetic source restored. Waiting for file monitor.');return
            c=sqlite3.connect(path)
            try:
                total=c.execute('SELECT COUNT(*) FROM raw_transactions').fetchone()[0]
                if total>=10113:raise ValueError('Replay limit reached. Restore synthetic data before replaying again.')
                aid=c.execute("SELECT MAX(CAST(account_id AS INTEGER))+1 FROM raw_accounts WHERE account_id NOT GLOB '*[^0-9]*'").fetchone()[0];tid=c.execute("SELECT MAX(CAST(transaction_id AS INTEGER))+1 FROM raw_transactions WHERE transaction_id NOT GLOB '*[^0-9]*'").fetchone()[0]
                c.execute('INSERT INTO raw_accounts VALUES (NULL,?,?,?)',(str(aid),'2025-12-30 00:00:00','US'))
                for i in range(20):c.execute('INSERT INTO raw_transactions VALUES (NULL,?,?,?,?,?,?)',(str(tid+i),str(aid),f'2025-12-31 23:58:{i:02d}',str(48000+i*150),'web','1'))
                c.commit();self.log('SOURCE SAVED','20 synthetic transactions appended without outcome labels. Waiting for file monitor.')
            finally:c.close()

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def allowed(self):
        hosts={f'localhost:{self.server.server_port}',f'127.0.0.1:{self.server.server_port}'}
        return self.headers.get('Host') in hosts and (not self.headers.get('Origin') or self.headers['Origin'] in {'http://'+h for h in hosts})
    def send(self,data,status=200,mime='application/json; charset=utf-8',filename=None):
        self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'")
        if filename:self.send_header('Content-Disposition',f'attachment; filename="{filename}"')
        self.end_headers();self.wfile.write(data)
    def respond(self,data,status=200):self.send(json.dumps(data,allow_nan=False).encode(),status)
    def do_GET(self):
        if not self.allowed():self.respond({'error':'Local origin required'},403);return
        path=urlparse(self.path).path
        if path=='/api/data':self.respond(self.server.engine.view());return
        if path in ['/api/export/monthly','/api/export/risk_tiers','/api/export/scored_queue']:
            name=path.rsplit('/',1)[1]+'.csv';file=self.server.engine.root/'exports'/name
            with self.server.engine.lock:
                if not file.exists():self.respond({'error':'No validated export'},503);return
                self.send(file.read_bytes(),mime='text/csv; charset=utf-8',filename='SYNTHETIC_'+name)
            return
        names={'/':'index.html','/index.html':'index.html','/style.css':'style.css','/app.js':'app.js'}
        if path not in names:self.respond({'error':'Not found'},404);return
        name=names[path];self.send((self.server.engine.root/'web'/name).read_bytes(),mime=mimetypes.guess_type(name)[0]+'; charset=utf-8')
    def do_POST(self):
        if not self.allowed():self.respond({'error':'Local origin required'},403);return
        if 'application/json' not in self.headers.get('Content-Type',''):self.respond({'error':'JSON required'},415);return
        try:
            size=int(self.headers.get('Content-Length',0))
            if not 0<=size<=10000:raise ValueError('Request too large')
            body=json.loads(self.rfile.read(size) or '{}')
            if not isinstance(body,dict):raise ValueError('Object required')
            e=self.server.engine
            if self.path=='/api/refresh':e.refresh(True);self.respond(e.view());return
            if self.path in ['/api/replay','/api/restore']:e.replay(self.path.endswith('restore'));self.respond({'saved':True});return
            if self.path=='/api/scenario':
                with e.lock:
                    if not e.good:raise ValueError('No validated results')
                    self.respond(scenario(e.good['test'],body['inputs']));return
            self.respond({'error':'Not found'},404)
        except (ValueError,KeyError,TypeError) as ex:self.respond({'error':str(ex)[:200]},400)

def main():
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8766);p.add_argument('--open',action='store_true');p.add_argument('--check',action='store_true');a=p.parse_args()
    if not (ROOT/'models/gradient_boosting.joblib').exists():train()
    e=Engine();e.refresh(True)
    if a.check:print(e.status,e.error or 'SQL, model and exports verified');return 0 if e.status=='ready' else 1
    http=ThreadingHTTPServer(('127.0.0.1',a.port),Handler);http.daemon_threads=True;http.engine=e
    threading.Thread(target=e.watch,daemon=True).start();url=f'http://127.0.0.1:{http.server_port}'
    print('Local: '+url,flush=True);print('Synthetic-only. File monitoring active while this service runs.',flush=True)
    if a.open:webbrowser.open(url)
    try:http.serve_forever()
    except KeyboardInterrupt:pass
    finally:e.stop.set();http.server_close()
    return 0
if __name__=='__main__':raise SystemExit(main())
